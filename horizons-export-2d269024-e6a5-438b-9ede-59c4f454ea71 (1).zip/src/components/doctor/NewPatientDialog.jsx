
    import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea'; 
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Loader2, Copy, CheckCircle } from 'lucide-react';

    const generateAccessCodeString = () => {
      const characters = 'ABCDEFGHIJKLMNPQRSTUVWXYZ123456789';
      let code = '';
      for (let i = 0; i < 7; i++) {
        code += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return `ID-${code}`;
    };

    const NewPatientDialog = ({ isOpen, setIsOpen, onPatientCreated, doctorId }) => {
      const { toast } = useToast();
      const [newPatientForm, setNewPatientForm] = useState({ name: '', date_of_birth: '', phone_number: '', address: '', initial_medical_notes: ''});
      const [isGeneratingCode, setIsGeneratingCode] = useState(false);
      const [generatedCodeInfo, setGeneratedCodeInfo] = useState({ code: '', patientName: '' });
      const [isCopied, setIsCopied] = useState(false);

      const resetDialog = () => {
        setIsOpen(false);
        setGeneratedCodeInfo({ code: '', patientName: '' });
        setNewPatientForm({ name: '', date_of_birth: '', phone_number: '', address: '', initial_medical_notes: ''});
      };

      const handleNewPatientSubmit = async (e) => {
        e.preventDefault();
        if (!newPatientForm.name.trim()) {
          toast({ title: 'Error', description: 'El nombre del paciente es requerido.', variant: 'destructive' });
          return;
        }
        setIsGeneratingCode(true);
        
        let newCode = generateAccessCodeString();
        let codeExists = true;
        let attempts = 0;

        while(codeExists && attempts < 10) {
          const { data: existingPatient, error: checkError } = await supabase.from('patients').select('access_code').eq('access_code', newCode).maybeSingle();
          if (checkError && checkError.code !== 'PGRST116') { 
            toast({ title: 'Error', description: 'Error al verificar el código: ' + checkError.message, variant: 'destructive' });
            setIsGeneratingCode(false);
            return;
          }
          codeExists = !!existingPatient;
          if (codeExists) newCode = generateAccessCodeString();
          attempts++;
        }

        if (codeExists) {
          toast({ title: 'Error', description: 'No se pudo generar un código único. Inténtalo de nuevo.', variant: 'destructive' });
          setIsGeneratingCode(false);
          return;
        }
        
        const patientToInsert = {
          ...newPatientForm,
          doctor_id: doctorId,
          access_code: newCode,
          access_code_status: 'active', 
        };

        const { data: insertedPatient, error: insertError } = await supabase
          .from('patients')
          .insert(patientToInsert)
          .select()
          .single();

        if (insertError) {
          toast({ title: 'Error', description: 'No se pudo crear el paciente: ' + insertError.message, variant: 'destructive' });
        } else {
          if (insertedPatient && newPatientForm.initial_medical_notes) {
            await supabase.from('medical_records').insert({
              patient_id: insertedPatient.id,
              doctor_id: doctorId,
              record_date: new Date().toISOString().split('T')[0],
              title: 'Notas Iniciales de Registro',
              content_type: 'text',
              content_text: newPatientForm.initial_medical_notes,
            });
          }
          toast({ title: 'Éxito', description: `Paciente ${insertedPatient.name} creado.` });
          setGeneratedCodeInfo({
            code: newCode,
            patientName: insertedPatient.name,
          });
          onPatientCreated(); // Callback to refresh patient list
          // Keep form data for now, reset happens on dialog close or explicit action
        }
        setIsGeneratingCode(false);
      };

      const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text).then(() => {
          setIsCopied(true);
          toast({ title: 'Copiado', description: 'Código copiado al portapapeles.' });
          setTimeout(() => setIsCopied(false), 2000);
        });
      };

      return (
        <Dialog open={isOpen} onOpenChange={(open) => { if(!open) resetDialog(); else setIsOpen(true);}}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{generatedCodeInfo.code ? `Código para ${generatedCodeInfo.patientName}` : 'Registrar Nuevo Paciente'}</DialogTitle>
              {!generatedCodeInfo.code && <DialogDescription>Completa los datos para registrar un nuevo paciente y generar su código de acceso.</DialogDescription>}
            </DialogHeader>
            {generatedCodeInfo.code ? (
              <div className="py-6 text-center">
                <p className="text-sm text-muted-foreground">Código de acceso para {generatedCodeInfo.patientName}:</p>
                <div className="flex items-center justify-center space-x-2 mt-2">
                  <p className="text-2xl font-bold text-primary tracking-wider p-3 bg-primary/10 rounded-md">{generatedCodeInfo.code}</p>
                  <Button variant="ghost" size="icon" onClick={() => copyToClipboard(generatedCodeInfo.code)} disabled={isCopied}>
                    {isCopied ? <CheckCircle className="h-5 w-5 text-green-500" /> : <Copy className="h-5 w-5" />}
                  </Button>
                </div>
                <p className="mt-4 text-xs text-muted-foreground">Este código es único y permitirá al paciente acceder a su portal. No expira.</p>
              </div>
            ) : (
              <form onSubmit={handleNewPatientSubmit}>
                <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right col-span-1">Nombre*</Label>
                    <Input id="name" value={newPatientForm.name} onChange={(e) => setNewPatientForm({...newPatientForm, name: e.target.value})} className="col-span-3" required />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dob" className="text-right col-span-1">F. Nacimiento</Label>
                    <Input id="dob" type="date" value={newPatientForm.date_of_birth} onChange={(e) => setNewPatientForm({...newPatientForm, date_of_birth: e.target.value})} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="phone" className="text-right col-span-1">Teléfono</Label>
                    <Input id="phone" value={newPatientForm.phone_number} onChange={(e) => setNewPatientForm({...newPatientForm, phone_number: e.target.value})} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="address" className="text-right col-span-1">Dirección</Label>
                    <Input id="address" value={newPatientForm.address} onChange={(e) => setNewPatientForm({...newPatientForm, address: e.target.value})} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4">
                    <Label htmlFor="initial_notes" className="text-right col-span-1 mt-2">Notas Iniciales</Label>
                    <Textarea id="initial_notes" value={newPatientForm.initial_medical_notes} onChange={(e) => setNewPatientForm({...newPatientForm, initial_medical_notes: e.target.value})} className="col-span-3" placeholder="Alergias, condiciones preexistentes, etc."/>
                  </div>
                </div>
                <DialogFooter className="mt-4">
                  <Button type="button" variant="outline" onClick={resetDialog}>Cancelar</Button>
                  <Button type="submit" disabled={isGeneratingCode || !newPatientForm.name.trim()} className="bg-primary hover:bg-primary/90">
                    {isGeneratingCode ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                    Registrar y Generar Código
                  </Button>
                </DialogFooter>
              </form>
            )}
            {generatedCodeInfo.code && (
              <DialogFooter>
                  <Button type="button" variant="secondary" onClick={resetDialog}>Cerrar</Button>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>
      );
    };

    export default NewPatientDialog;
  
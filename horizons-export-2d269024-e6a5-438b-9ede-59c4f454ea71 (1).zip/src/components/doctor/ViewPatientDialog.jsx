
    import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Copy, CheckCircle, RefreshCw, Trash2 } from 'lucide-react';
    import { format } from 'date-fns';

    const generateAccessCodeString = () => {
      const characters = 'ABCDEFGHIJKLMNPQRSTUVWXYZ123456789';
      let code = '';
      for (let i = 0; i < 7; i++) {
        code += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return `ID-${code}`;
    };

    const ViewPatientDialog = ({ isOpen, setIsOpen, patient, onCodeRegenerated, onPatientDeleted }) => {
      const { toast } = useToast();
      const [isCopied, setIsCopied] = useState(false);
      const [currentPatientData, setCurrentPatientData] = useState(patient);

      React.useEffect(() => {
        setCurrentPatientData(patient);
      }, [patient]);


      const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text).then(() => {
          setIsCopied(true);
          toast({ title: 'Copiado', description: 'Código copiado al portapapeles.' });
          setTimeout(() => setIsCopied(false), 2000);
        });
      };

      const regenerateAccessCode = async () => {
        if (!currentPatientData || !window.confirm("¿Estás seguro de que quieres invalidar el código actual y generar uno nuevo para este paciente?")) return;
        
        let newCode = generateAccessCodeString();
        let codeExists = true;
        let attempts = 0;
        while(codeExists && attempts < 10) {
          const { data: existingPatient } = await supabase.from('patients').select('access_code').eq('access_code', newCode).maybeSingle();
          codeExists = !!existingPatient;
          if (codeExists) newCode = generateAccessCodeString();
          attempts++;
        }
        if (codeExists) {
          toast({ title: 'Error', description: 'No se pudo generar un código único. Inténtalo de nuevo.', variant: 'destructive' });
          return;
        }

        const { data, error } = await supabase
          .from('patients')
          .update({ 
            access_code: newCode, 
            access_code_status: 'active', 
            access_code_used_at: null,
          })
          .eq('id', currentPatientData.id)
          .select()
          .single();

        if (error) {
          toast({ title: 'Error', description: 'No se pudo regenerar el código: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Nuevo código de acceso generado para ${data.name}.` });
          setCurrentPatientData(data);
          if (onCodeRegenerated) onCodeRegenerated();
        }
      };
      
      const handleDeletePatient = async () => {
        if (!currentPatientData || !window.confirm(`¿Estás seguro de que quieres eliminar al paciente ${currentPatientData.name}? Esta acción no se puede deshacer y también eliminará los datos asociados (citas, historial, recetas, mensajes).`)) return;
        
        try {
          await supabase.from('messages').delete().or(`sender_id.eq.${currentPatientData.id},receiver_id.eq.${currentPatientData.id}`);
          await supabase.from('prescriptions').delete().eq('patient_id', currentPatientData.id);
          await supabase.from('medical_records').delete().eq('patient_id', currentPatientData.id);
          await supabase.from('appointments').delete().eq('patient_id', currentPatientData.id);
          
          const { error: patientDeleteError } = await supabase
            .from('patients')
            .update({ access_code_status: 'deleted', name: `Eliminado (${currentPatientData.name})` })
            .eq('id', currentPatientData.id);

          if (patientDeleteError) throw patientDeleteError;

          toast({ title: 'Éxito', description: `Paciente ${currentPatientData.name} ha sido marcado como eliminado.` });
          if (onPatientDeleted) onPatientDeleted();
          setIsOpen(false);
          
        } catch (error) {
           toast({ title: 'Error', description: 'No se pudo eliminar el paciente: ' + error.message, variant: 'destructive' });
        }
      };


      if (!currentPatientData) return null;

      return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{currentPatientData.name}</DialogTitle>
              <DialogDescription>Información Detallada del Paciente</DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-3 max-h-[70vh] overflow-y-auto pr-2">
                <p><strong>Nombre:</strong> {currentPatientData.name}</p>
                <p><strong>Fecha de Nacimiento:</strong> {currentPatientData.date_of_birth ? format(new Date(currentPatientData.date_of_birth), "dd/MM/yyyy") : 'No especificado'}</p>
                <p><strong>Teléfono:</strong> {currentPatientData.phone_number || 'No especificado'}</p>
                <p><strong>Dirección:</strong> {currentPatientData.address || 'No especificado'}</p>
                <div className="flex items-center">
                    <strong>Código de Acceso:</strong> 
                    <span className="ml-2 font-mono bg-slate-100 px-2 py-1 rounded text-primary">{currentPatientData.access_code}</span>
                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard(currentPatientData.access_code)} className="ml-1">
                        {isCopied ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                    </Button>
                </div>
                <p><strong>Estado del Código:</strong> <span className={`capitalize font-medium ${currentPatientData.access_code_status === 'active' ? 'text-green-600' : 'text-orange-600'}`}>{currentPatientData.access_code_status}</span></p>
                {currentPatientData.access_code_used_at && <p><strong>Último Uso (si aplica):</strong> {format(new Date(currentPatientData.access_code_used_at), "dd/MM/yyyy HH:mm:ss")}</p>}
                
                <p className="text-sm text-muted-foreground">Registrado: {format(new Date(currentPatientData.created_at), "dd/MM/yyyy HH:mm")}</p>
                {currentPatientData.initial_medical_notes && (
                    <div>
                        <p className="font-semibold">Notas Iniciales de Registro:</p>
                        <p className="text-sm bg-slate-50 p-3 rounded border">{currentPatientData.initial_medical_notes}</p>
                    </div>
                )}
            </div>
            <DialogFooter className="justify-between items-center">
                <Button variant="destructiveOutline" size="sm" onClick={handleDeletePatient}>
                    <Trash2 className="mr-2 h-4 w-4" /> Eliminar Paciente
                </Button>
              <Button variant="outline" onClick={regenerateAccessCode}>
                <RefreshCw className="mr-2 h-4 w-4" /> Regenerar Código
              </Button>
              <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>Cerrar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };

    export default ViewPatientDialog;
  

    import React from 'react';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Users, Briefcase, Building, LogIn, Outdent as Tooth, Zap, ShieldCheck, MessageCircle } from 'lucide-react';
    import { motion } from 'framer-motion';

    const HomePage = () => {
      const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: (i) => ({
          opacity: 1,
          y: 0,
          transition: {
            delay: i * 0.15,
            duration: 0.5,
            ease: "easeOut"
          }
        })
      };

      const featureVariants = {
        hidden: { opacity: 0, x: -20 },
        visible: (i) => ({
          opacity: 1,
          x: 0,
          transition: {
            delay: i * 0.2 + 0.5, // Start after main animation
            duration: 0.5,
            ease: "easeOut"
          }
        })
      };
      
      const appDescription = {
        title: "Transforma tu Práctica Dental con Inteligencia Dental",
        subtitle: "Una plataforma integral diseñada para optimizar la gestión de tu consultorio, mejorar la comunicación con tus pacientes y simplificar tus operaciones diarias.",
        benefits: [
          { icon: Zap, title: "Gestión Eficiente", text: "Agenda citas, administra historiales clínicos y recetas médicas de forma centralizada y digital." },
          { icon: MessageCircle, title: "Comunicación Fluida", text: "Conéctate con tus pacientes a través de mensajería segura y mantén un seguimiento personalizado." },
          { icon: ShieldCheck, title: "Acceso Seguro y Personalizado", text: "Perfiles dedicados para doctores, clínicas y pacientes, con acceso controlado a la información relevante." }
        ]
      };

      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4 md:p-8 gradient-bg text-white overflow-x-hidden">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-center mb-10 md:mb-12"
          >
            <Tooth className="mx-auto h-20 w-20 md:h-24 md:w-24 text-white mb-4" />
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-3">Inteligencia Dental</h1>
            <p className="text-lg sm:text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
              {appDescription.subtitle}
            </p>
          </motion.div>

          <motion.div 
            className="my-10 md:my-12 p-6 md:p-8 glassmorphism-card max-w-4xl w-full"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <h2 className="text-2xl md:text-3xl font-semibold text-center text-brand-blue-dark mb-6">{appDescription.title}</h2>
            <div className="space-y-4">
              {appDescription.benefits.map((benefit, index) => (
                <motion.div 
                  key={index} 
                  custom={index}
                  variants={featureVariants}
                  initial="hidden"
                  animate="visible"
                  className="flex items-start space-x-3 p-3 bg-white/20 rounded-lg"
                >
                  <benefit.icon className="h-8 w-8 text-brand-teal flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-brand-blue-dark text-lg">{benefit.title}</h3>
                    <p className="text-brand-blue-dark/90 text-sm">{benefit.text}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 max-w-4xl w-full">
            {[
              { title: "Soy Doctor", icon: Briefcase, path: "/login/doctor", description: "Accede a tu panel profesional." },
              { title: "Soy Paciente", icon: Users, path: "/login/patient", description: "Ingresa con tu código único." },
              { title: "Soy Clínica", icon: Building, path: "/login/clinic", description: "Administra tu clínica y equipo." },
            ].map((item, index) => (
              <motion.div key={item.title} custom={index} variants={cardVariants} initial="hidden" animate="visible">
                <Card className="glassmorphism-card text-center hover:shadow-2xl transition-shadow duration-300 h-full flex flex-col">
                  <CardHeader className="flex-grow">
                    <item.icon className="mx-auto h-10 w-10 md:h-12 md:w-12 text-brand-blue-dark mb-3" />
                    <CardTitle className="text-xl md:text-2xl font-semibold text-brand-blue-dark">{item.title}</CardTitle>
                    <CardDescription className="text-brand-blue-dark/80 text-sm">{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="mt-auto">
                    <Button asChild variant="secondary" className="w-full bg-brand-teal hover:bg-brand-teal-dark text-white py-2.5 text-base">
                      <Link to={item.path}>
                        <LogIn className="mr-2 h-4 w-4" /> Acceder
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
          <footer className="mt-12 md:mt-16 text-center text-blue-200 text-sm">
            <p>&copy; {new Date().getFullYear()} Inteligencia Dental. Todos los derechos reservados.</p>
          </footer>
        </div>
      );
    };

    export default HomePage;
  
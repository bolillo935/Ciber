
    import React, { useState } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { Briefcase, LogIn, ArrowLeft, Outdent as Tooth, Mail } from 'lucide-react';
    import { motion } from 'framer-motion';

    const LoginPageDoctor = () => {
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const { loginDoctor, USER_ROLES } = useAuth();
      const navigate = useNavigate();
      const { toast } = useToast();

      const handleSubmit = async (e) => {
        e.preventDefault();
        if (!email || !password) {
          toast({ title: "Error", description: "Por favor, completa todos los campos.", variant: "destructive" });
          return;
        }
        const result = await loginDoctor(email, password);
        if (result.success) {
          toast({ title: "Éxito", description: `Bienvenido Dr. ${result.user.name}.` });
          navigate(`/dashboard/${USER_ROLES.DOCTOR}`);
        } else {
          toast({ title: "Error de inicio de sesión", description: result.message, variant: "destructive" });
        }
      };

      return (
        <div className="min-h-screen flex items-center justify-center p-4 gradient-bg">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="w-full max-w-md shadow-2xl">
              <CardHeader className="text-center">
                <Tooth className="mx-auto h-12 w-12 text-primary mb-2" />
                <CardTitle className="text-3xl font-bold text-primary">Acceso Doctor</CardTitle>
                <CardDescription>Ingresa tu correo electrónico y contraseña.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email">Correo Electrónico</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="tu.correo@ejemplo.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="text-base pl-10"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Tu contraseña"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="text-base"
                    />
                  </div>
                  <Button type="submit" className="w-full text-lg py-3 bg-primary hover:bg-primary/90">
                    <LogIn className="mr-2 h-5 w-5" /> Ingresar
                  </Button>
                </form>
              </CardContent>
              <CardFooter className="flex flex-col items-center">
                <p className="text-sm text-muted-foreground mb-2">
                  Las cuentas de doctor son creadas por un administrador.
                </p>
                <Button variant="link" asChild className="text-primary">
                  <Link to="/">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Volver al inicio
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default LoginPageDoctor;
  

    import React, { useState, useEffect, useCallback } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Eye } from 'lucide-react';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const MiExpedienteView = ({ patientId }) => {
        const [records, setRecords] = useState([]);
        const [isLoading, setIsLoading] = useState(true);
        const { toast } = useToast();

        const fetchRecords = useCallback(async () => {
            if(!patientId) { setIsLoading(false); setRecords([]); return; }
            setIsLoading(true);
            const { data, error } = await supabase
                .from('medical_records')
                .select('*, doctors(name)')
                .eq('patient_id', patientId)
                .order('record_date', { ascending: false });
            
            if (error) {
                toast({title: "Error", description: "No se pudo cargar tu expediente: " + error.message, variant: "destructive"});
                setRecords([]);
            } else {
                setRecords(data || []);
            }
            setIsLoading(false);
        }, [patientId, toast]);

        useEffect(() => {
            fetchRecords();
        }, [fetchRecords]);

        if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-teal-500" /> Cargando tu expediente...</div>;
        if (!records.length) return <p className="text-slate-500">No tienes registros en tu expediente.</p>;

        return (
            <div className="space-y-4">
                {records.map(rec => (
                    <Card key={rec.id}>
                        <CardHeader>
                            <CardTitle>{rec.title || `Registro del ${new Date(rec.record_date).toLocaleDateString()}`}</CardTitle>
                            <CardDescription>Registrado por: {rec.doctors?.name || 'Doctor'} | Tipo: {rec.content_type}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {rec.content_text && <p className="whitespace-pre-wrap">{rec.content_text}</p>}
                            {rec.file_url && 
                                <a 
                                    href={rec.file_url} 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="text-teal-600 hover:underline flex items-center"
                                     onClick={(e) => {
                                        e.preventDefault();
                                        window.open(rec.file_url, '_blank');
                                        toast({ title: 'Abriendo archivo...', description: 'Se está abriendo el archivo en una nueva pestaña.'});
                                    }}
                                >
                                    <Eye className="mr-2 h-4 w-4"/> Ver Archivo Adjunto ({rec.file_name || 'archivo'})
                                </a>
                            }
                            {rec.notes && <p className="text-sm text-muted-foreground mt-2">Notas adicionales: {rec.notes}</p>}
                        </CardContent>
                    </Card>
                ))}
            </div>
        );
    };
    export default MiExpedienteView;
  

    import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const SolicitarCitaView = ({ patient, onAppointmentRequested }) => {
        const { toast } = useToast();
        const [note, setNote] = useState('');
        const [desiredDateTime, setDesiredDateTime] = useState('');
        const [isSubmitting, setIsSubmitting] = useState(false);

        const handleSubmitRequest = async () => {
            if(!patient?.assignedDoctor?.id || !patient?.id) {
                toast({title: "Error", description: "Información de paciente o doctor no disponible.", variant: "destructive"});
                return;
            }
            if(!desiredDateTime) {
                toast({title: "Error", description: "Por favor, selecciona una fecha y hora deseada.", variant: "destructive"});
                return;
            }
            setIsSubmitting(true);
            
            const startTime = new Date(desiredDateTime);
            const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // Default 1 hour duration

            const { error } = await supabase.from('appointments').insert({
                doctor_id: patient.assignedDoctor.id,
                patient_id: patient.id,
                clinic_id: patient.assignedDoctor.primary_clinic_id || null, 
                start_time: startTime.toISOString(), 
                end_time: endTime.toISOString(), 
                status: 'requested_by_patient',
                notes: `Solicitud de cita. Nota del paciente: ${note || 'N/A'}`
            });

            if (error) {
                toast({title: "Error", description: "No se pudo enviar la solicitud: " + error.message, variant: "destructive"});
            } else {
                toast({title: "Éxito", description: "Solicitud de cita enviada. El doctor se pondrá en contacto."});
                setNote('');
                setDesiredDateTime('');
                if(onAppointmentRequested) onAppointmentRequested();
            }
            setIsSubmitting(false);
        };

        if (!patient?.assignedDoctor) return <p className="text-slate-500">No tienes un doctor asignado para solicitar citas.</p>;

        return (
            <div>
                <h3 className="text-xl font-semibold mb-2">Solicitar Cita con Dr. {patient.assignedDoctor.name}</h3>
                <div className="space-y-4">
                    <div>
                        <Label htmlFor="desiredDateTime">Fecha y Hora Deseada</Label>
                        <Input type="datetime-local" id="desiredDateTime" value={desiredDateTime} onChange={(e) => setDesiredDateTime(e.target.value)} min={new Date().toISOString().slice(0,16)} />
                    </div>
                    <div>
                        <Label htmlFor="appointmentNote">Motivo o Nota (opcional)</Label>
                        <Textarea id="appointmentNote" value={note} onChange={(e) => setNote(e.target.value)} className="w-full p-2 border rounded-md h-24 bg-white" placeholder="Ej: Revisión general, dolor en una muela..."/>
                    </div>
                    <Button onClick={handleSubmitRequest} disabled={isSubmitting || !desiredDateTime}>
                        {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enviando...</> : "Enviar Solicitud"}
                    </Button>
                </div>
            </div>
        );
    };
    export default SolicitarCitaView;
  
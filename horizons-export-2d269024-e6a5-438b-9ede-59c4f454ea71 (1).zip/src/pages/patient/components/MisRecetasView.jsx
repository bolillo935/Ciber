
    import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const MisRecetasView = ({ patientId }) => {
        const [prescriptions, setPrescriptions] = useState([]);
        const [isLoading, setIsLoading] = useState(true);
        const { toast } = useToast();

        const fetchPrescriptions = useCallback(async () => {
            if(!patientId) { setIsLoading(false); setPrescriptions([]); return; }
            setIsLoading(true);
            const { data, error } = await supabase
                .from('prescriptions')
                .select('*, doctors(name)')
                .eq('patient_id', patientId)
                .order('issue_date', { ascending: false });

            if (error) {
                toast({title: "Error", description: "No se pudieron cargar tus recetas: " + error.message, variant: "destructive"});
                setPrescriptions([]);
            } else {
                setPrescriptions(data || []);
            }
            setIsLoading(false);
        }, [patientId, toast]);

        useEffect(() => {
            fetchPrescriptions();
        }, [fetchPrescriptions]);

        if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-teal-500" /> Cargando tus recetas...</div>;
        if (!prescriptions.length) return <p className="text-slate-500">No tienes recetas registradas.</p>;

        return (
            <div className="space-y-4">
                {prescriptions.map(presc => (
                    <Card key={presc.id}>
                        <CardHeader>
                            <CardTitle>Receta del {new Date(presc.issue_date).toLocaleDateString()}</CardTitle>
                            <CardDescription>Emitida por: {presc.doctors?.name || 'Doctor'}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <p><span className="font-semibold">Medicamento:</span> {presc.medication}</p>
                            {presc.dosage && <p><span className="font-semibold">Dosis:</span> {presc.dosage}</p>}
                            {presc.instructions && <p><span className="font-semibold">Instrucciones:</span> {presc.instructions}</p>}
                            {presc.duration && <p><span className="font-semibold">Duración:</span> {presc.duration}</p>}
                            {presc.notes && <p className="text-sm text-muted-foreground mt-2">Notas: {presc.notes}</p>}
                            <Button size="sm" variant="link" className="mt-2 p-0 h-auto" onClick={() => alert(`Simulando descarga de receta ID: ${presc.id}`)}>Ver/Descargar Receta (Simulado)</Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        );
    };
    export default MisRecetasView;
  

    import React, { useState, useEffect, useCallback } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const MisCitasView = ({ patientId, refreshTrigger }) => {
      const [appointments, setAppointments] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const { toast } = useToast();

      const fetchAppointments = useCallback(async () => {
        if(!patientId) {
          setIsLoading(false);
          setAppointments([]);
          return;
        }
        setIsLoading(true);
        const { data, error } = await supabase
          .from('appointments')
          .select('*, doctors(name, specialty)')
          .eq('patient_id', patientId)
          .order('start_time', { ascending: false });
        
        if (error) {
          toast({title: "Error", description: "No se pudieron cargar tus citas: " + error.message, variant: "destructive"});
          setAppointments([]);
        } else {
          setAppointments(data || []);
        }
        setIsLoading(false);
      }, [patientId, toast]);

      useEffect(() => {
        fetchAppointments();
      }, [fetchAppointments, refreshTrigger]);

      if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando tus citas...</div>;
      if (!appointments.length) return <p className="text-slate-500">No tienes citas programadas o solicitadas.</p>;

      return (
        <div className="space-y-4">
          {appointments.map(app => (
            <Card key={app.id}>
              <CardContent className="p-4">
                <CardTitle className="text-lg mb-1">Cita con {app.doctors?.name || 'Doctor Asignado'}</CardTitle>
                <CardDescription>
                  {new Date(app.start_time).toLocaleString([], {dateStyle: 'long', timeStyle: 'short'})}
                </CardDescription>
                <p className="text-sm text-muted-foreground mt-1">Estado: {app.status}</p>
                {app.notes && <p className="text-sm mt-1">Notas: {app.notes}</p>}
              </CardContent>
            </Card>
          ))}
        </div>
      );
    };
    export default MisCitasView;
  
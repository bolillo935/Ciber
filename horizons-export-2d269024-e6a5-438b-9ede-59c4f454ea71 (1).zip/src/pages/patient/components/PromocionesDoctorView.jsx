
    import React, { useState, useEffect, useCallback } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const PromocionesDoctorView = ({ doctorId }) => {
        const [promotions, setPromotions] = useState([]);
        const [isLoading, setIsLoading] = useState(true);
        const { toast } = useToast();

        const fetchPromotions = useCallback(async () => {
            if(!doctorId) { setIsLoading(false); setPromotions([]); return; }
            setIsLoading(true);
            const { data, error } = await supabase
                .from('promotions')
                .select('*')
                .eq('publisher_id', doctorId)
                .eq('publisher_type', 'doctor')
                .eq('is_active', true)
                .order('created_at', { ascending: false });
            
            if (error) {
                toast({title: "Error", description: "No se pudieron cargar las promociones: " + error.message, variant: "destructive"});
                setPromotions([]);
            } else {
                setPromotions(data || []);
            }
            setIsLoading(false);
        }, [doctorId, toast]);

        useEffect(() => {
            fetchPromotions();
        }, [fetchPromotions]);

        if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-teal-500" /> Cargando promociones...</div>;
        if (!promotions.length) return <p className="text-slate-500">Tu doctor no tiene promociones activas en este momento.</p>;

        return (
            <div className="space-y-4">
                {promotions.map(promo => (
                    <Card key={promo.id} className="bg-teal-50 border-teal-200">
                        <CardHeader>
                            <CardTitle className="text-teal-700">{promo.title}</CardTitle>
                             {promo.start_date && promo.end_date &&
                                <CardDescription>
                                    Válido del {new Date(promo.start_date).toLocaleDateString()} al {new Date(promo.end_date).toLocaleDateString()}
                                </CardDescription>
                            }
                        </CardHeader>
                        <CardContent>
                            <p>{promo.description}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        );
    };
    export default PromocionesDoctorView;
  
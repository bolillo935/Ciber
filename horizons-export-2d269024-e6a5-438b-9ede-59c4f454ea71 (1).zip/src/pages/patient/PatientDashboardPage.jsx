
    import React, { useState, useEffect, useRef } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { LogOut, UserCircle, Stethoscope, CalendarDays, FileText, ListChecks, Send, MessageSquare, Bell, Loader2, Copy, CheckCircle } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
    import { format, parseISO, formatDistanceToNow } from 'date-fns';
    import { es } from 'date-fns/locale';

    const PatientDashboardPage = () => {
      const { user, logout } = useAuth();
      const { toast } = useToast();
      const [activeTab, setActiveTab] = useState("info");

      const [appointments, setAppointments] = useState([]);
      const [medicalRecords, setMedicalRecords] = useState([]);
      const [prescriptions, setPrescriptions] = useState([]);
      const [promotions, setPromotions] = useState([]);
      
      const [messages, setMessages] = useState([]);
      const [newMessage, setNewMessage] = useState('');
      const [isLoadingMessages, setIsLoadingMessages] = useState(false);
      const [isSendingMessage, setIsSendingMessage] = useState(false);
      const messagesEndRef = useRef(null);
      const [isLoadingData, setIsLoadingData] = useState({
        appointments: false, records: false, prescriptions: false, promotions: false
      });
      const [isAccessCodeCopied, setIsAccessCodeCopied] = useState(false);

      const fetchPatientData = async (dataType) => {
        if (!user || !user.id || !user.accessCode ) return;
        
        setIsLoadingData(prev => ({ ...prev, [dataType]: true }));
        let queryResult;

        try {
          switch (dataType) {
            case 'appointments':
              queryResult = await supabase.from('appointments').select('*, doctors(name, specialty)')
                            .eq('patient_id', user.id)
                            .order('start_time', { ascending: false });
              if (queryResult.data) setAppointments(queryResult.data);
              break;
            case 'records':
              queryResult = await supabase.from('medical_records').select('*, doctors(name)')
                            .eq('patient_id', user.id)
                            .order('record_date', { ascending: false });
              if (queryResult.data) setMedicalRecords(queryResult.data);
              break;
            case 'prescriptions':
              queryResult = await supabase.from('prescriptions').select('*, doctors(name)')
                            .eq('patient_id', user.id)
                            .order('issue_date', { ascending: false });
              if (queryResult.data) setPrescriptions(queryResult.data);
              break;
            case 'promotions':
              if (!user.assignedDoctor?.id) { 
                setPromotions([]); 
                setIsLoadingData(prev => ({ ...prev, [dataType]: false }));
                return;
              }
              queryResult = await supabase.from('promotions').select('*')
                            .eq('publisher_id', user.assignedDoctor.id)
                            .eq('publisher_type', 'doctor')
                            .eq('is_active', true)
                            .order('created_at', { ascending: false });
              if (queryResult.data) setPromotions(queryResult.data);
              break;
            default:
              setIsLoadingData(prev => ({ ...prev, [dataType]: false }));
              return;
          }
          
          if (queryResult && queryResult.error) {
            toast({ title: `Error cargando ${dataType}`, description: queryResult.error.message, variant: "destructive" });
          }
        } catch (error) {
          toast({ title: `Excepción cargando ${dataType}`, description: error.message, variant: "destructive" });
        } finally {
          setIsLoadingData(prev => ({ ...prev, [dataType]: false }));
        }
      };

      const fetchMessagesForPatient = async () => {
        if (!user || !user.id || !user.assignedDoctor?.id) return;
        setIsLoadingMessages(true);
        const { data, error } = await supabase
          .from('messages')
          .select('*')
          .or(`(sender_id.eq.${user.id},receiver_id.eq.${user.assignedDoctor.id}),(sender_id.eq.${user.assignedDoctor.id},receiver_id.eq.${user.id})`)
          .order('created_at', { ascending: true });
          
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los mensajes: ' + error.message, variant: 'destructive' });
        } else {
          setMessages(data || []);
        }
        setIsLoadingMessages(false);
      };
      
      useEffect(() => {
        if (user && user.role === 'patient') {
          fetchPatientData('appointments');
          fetchPatientData('records');
          fetchPatientData('prescriptions');
          fetchPatientData('promotions');
          fetchMessagesForPatient();

          const messagesChannel = supabase
            .channel(`messages:patient-${user.id}:doctor-${user.assignedDoctor?.id}`)
            .on('postgres_changes', { 
                event: 'INSERT', 
                schema: 'public', 
                table: 'messages',
                filter: `receiver_id=eq.${user.id}`
              }, 
              (payload) => {
                setMessages((prevMessages) => [...prevMessages, payload.new]);
              }
            )
            .subscribe();

          return () => {
            supabase.removeChannel(messagesChannel);
          };
        }
      }, [user]);

      useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, [messages]);

      const handleSendMessageToDoctor = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !user.assignedDoctor?.id) return;
        setIsSendingMessage(true);

        const messageData = {
          sender_id: user.id,
          receiver_id: user.assignedDoctor.id,
          sender_role: 'patient',
          receiver_role: 'doctor',
          content: newMessage.trim(),
        };

        const { data: insertedMessage, error } = await supabase.from('messages').insert(messageData).select().single();
        
        if (error) {
          toast({ title: 'Error', description: 'No se pudo enviar el mensaje: ' + error.message, variant: 'destructive' });
        } else {
          setNewMessage('');
          setMessages(prev => [...prev, insertedMessage]);
        }
        setIsSendingMessage(false);
      };

      const copyAccessCode = () => {
        navigator.clipboard.writeText(user.accessCode).then(() => {
          setIsAccessCodeCopied(true);
          toast({ title: "Copiado", description: "Código de acceso copiado." });
          setTimeout(() => setIsAccessCodeCopied(false), 2000);
        });
      };
      
      const tabContentVariants = {
        hidden: { opacity: 0, y: 10 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
      };

      return (
        <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 p-4 md:p-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-5xl mx-auto"
          >
            <header className="flex flex-col sm:flex-row justify-between items-center mb-8 pb-4 border-b border-secondary/30">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-secondary text-center sm:text-left">Portal del Paciente</h1>
                {user && <p className="text-lg md:text-xl text-slate-600 text-center sm:text-left">Bienvenido, {user.name}</p>}
              </div>
              <Button onClick={logout} variant="outline" className="mt-4 sm:mt-0 border-secondary text-secondary hover:bg-secondary/10">
                <LogOut className="mr-2 h-4 w-4" /> Cerrar Sesión
              </Button>
            </header>

            <Tabs defaultValue="info" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-5 mb-6">
                <TabsTrigger value="info"><UserCircle className="mr-1 sm:mr-2 h-4 w-4 inline-block"/>Mi Info</TabsTrigger>
                <TabsTrigger value="citas"><CalendarDays className="mr-1 sm:mr-2 h-4 w-4 inline-block"/>Citas</TabsTrigger>
                <TabsTrigger value="historial"><FileText className="mr-1 sm:mr-2 h-4 w-4 inline-block"/>Historial</TabsTrigger>
                <TabsTrigger value="recetas"><ListChecks className="mr-1 sm:mr-2 h-4 w-4 inline-block"/>Recetas</TabsTrigger>
                <TabsTrigger value="mensajes"><MessageSquare className="mr-1 sm:mr-2 h-4 w-4 inline-block"/>Mensajes</TabsTrigger>
              </TabsList>

              <motion.div key={activeTab} variants={tabContentVariants} initial="hidden" animate="visible">
                <TabsContent value="info">
                  <Card className="shadow-xl">
                    <CardHeader>
                      <CardTitle className="text-2xl font-semibold text-secondary flex items-center">
                        <Stethoscope className="mr-3 h-7 w-7" /> Tu Doctor Asignado
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {user && user.assignedDoctor ? (
                        <>
                          <p className="text-lg text-slate-700">Nombre: <span className="font-medium">{user.assignedDoctor.name}</span></p>
                          <p className="text-lg text-slate-700">Especialidad: <span className="font-medium">{user.assignedDoctor.specialty}</span></p>
                          <div className="text-sm text-slate-500 mt-4 flex items-center">
                            <span>Código de Acceso: </span>
                            <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded ml-1 mr-1">{user.accessCode}</span>
                            <Button variant="ghost" size="iconSm" onClick={copyAccessCode}>
                                {isAccessCodeCopied ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4 text-slate-500" />}
                            </Button>
                          </div>
                          <p className="text-xs text-slate-500">(Guarda este código para futuros accesos)</p>
                        </>
                      ) : <p className="text-slate-600">No tienes un doctor asignado.</p>}
                      
                      <div className="mt-6 pt-4 border-t">
                        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center"><Bell className="mr-2 h-5 w-5"/>Promociones de tu Doctor</h3>
                        {isLoadingData.promotions ? <Loader2 className="h-6 w-6 animate-spin text-secondary"/> : promotions.length > 0 ? (
                            <ul className="space-y-2">
                                {promotions.map(promo => (
                                    <li key={promo.id} className="p-3 bg-teal-50 border border-teal-200 rounded-md">
                                        <h4 className="font-semibold text-teal-700">{promo.title}</h4>
                                        <p className="text-sm text-teal-600">{promo.description}</p>
                                    </li>
                                ))}
                            </ul>
                        ) : <p className="text-sm text-slate-500">No hay promociones activas de tu doctor en este momento.</p>}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="citas">
                  <Card className="shadow-xl">
                    <CardHeader><CardTitle className="text-2xl font-semibold text-secondary">Mis Citas</CardTitle></CardHeader>
                    <CardContent>
                      {isLoadingData.appointments ? <Loader2 className="h-6 w-6 animate-spin text-secondary"/> : appointments.length > 0 ? (
                        <ul className="space-y-3">
                          {appointments.map(app => (
                            <li key={app.id} className="p-3 bg-emerald-50 border border-emerald-200 rounded-md">
                              <p className="font-medium text-emerald-700">Fecha: {format(parseISO(app.start_time), "PPPp", { locale: es })}</p>
                              <p className="text-sm text-emerald-600">Doctor: {app.doctors?.name || 'N/A'}</p>
                              {app.notes && <p className="text-xs text-emerald-500 mt-1">Notas: {app.notes}</p>}
                            </li>
                          ))}
                        </ul>
                      ) : <p className="text-sm text-slate-500">No tienes citas programadas.</p>}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="historial">
                   <Card className="shadow-xl">
                    <CardHeader><CardTitle className="text-2xl font-semibold text-secondary">Mi Historial Clínico</CardTitle></CardHeader>
                    <CardContent>
                      {isLoadingData.records ? <Loader2 className="h-6 w-6 animate-spin text-secondary"/> : medicalRecords.length > 0 ? (
                        <ul className="space-y-3">
                          {medicalRecords.map(rec => (
                            <li key={rec.id} className="p-3 bg-sky-50 border border-sky-200 rounded-md">
                              <p className="font-medium text-sky-700">{rec.title} - {format(parseISO(rec.record_date), "PPP", { locale: es })}</p>
                              <p className="text-sm text-sky-600 whitespace-pre-wrap">{rec.content_text}</p>
                            </li>
                          ))}
                        </ul>
                      ) : <p className="text-sm text-slate-500">No hay entradas en tu historial clínico.</p>}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="recetas">
                  <Card className="shadow-xl">
                    <CardHeader><CardTitle className="text-2xl font-semibold text-secondary">Mis Recetas</CardTitle></CardHeader>
                    <CardContent>
                      {isLoadingData.prescriptions ? <Loader2 className="h-6 w-6 animate-spin text-secondary"/> : prescriptions.length > 0 ? (
                        <ul className="space-y-3">
                          {prescriptions.map(presc => (
                            <li key={presc.id} className="p-3 bg-indigo-50 border border-indigo-200 rounded-md">
                              <p className="font-medium text-indigo-700">Medicamento: {presc.medication} ({format(parseISO(presc.issue_date), "PPP", { locale: es })})</p>
                              {presc.dosage && <p className="text-sm text-indigo-600">Dosis: {presc.dosage}</p>}
                              {presc.instructions && <p className="text-sm text-indigo-600">Instrucciones: {presc.instructions}</p>}
                            </li>
                          ))}
                        </ul>
                      ) : <p className="text-sm text-slate-500">No tienes recetas registradas.</p>}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="mensajes">
                    <Card className="shadow-xl">
                        <CardHeader>
                            <CardTitle className="text-2xl font-semibold text-secondary">Mensajes con tu Doctor</CardTitle>
                            {user.assignedDoctor && <CardDescription>Doctor: {user.assignedDoctor.name}</CardDescription>}
                        </CardHeader>
                        <CardContent className="flex flex-col h-[60vh]">
                            <div className="flex-grow overflow-y-auto mb-4 p-3 space-y-3 bg-slate-100 rounded-md">
                                {isLoadingMessages ? <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-secondary" /></div> :
                                messages.length > 0 ? (
                                    messages.map(msg => (
                                    <div key={msg.id} className={`flex flex-col ${msg.sender_id === user.id ? 'items-end' : 'items-start'}`}>
                                        <div className={`max-w-xs lg:max-w-md px-3 py-2 rounded-xl shadow-md ${msg.sender_id === user.id ? 'bg-secondary text-secondary-foreground rounded-br-none' : 'bg-white text-slate-800 border rounded-bl-none'}`}>
                                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                                        </div>
                                        <p className={`text-xs mt-1 ${msg.sender_id === user.id ? 'text-slate-400 mr-1' : 'text-slate-400 ml-1'}`}>
                                            {formatDistanceToNow(parseISO(msg.created_at), { addSuffix: true, locale: es })}
                                        </p>
                                    </div>
                                    ))
                                ) : <p className="text-sm text-slate-500 text-center py-4">No hay mensajes en este chat.</p>
                                }
                                <div ref={messagesEndRef} />
                            </div>
                             {user.assignedDoctor && (
                                <form onSubmit={handleSendMessageToDoctor} className="flex gap-2 items-end">
                                    <Textarea 
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    placeholder="Escribe tu mensaje a tu doctor..."
                                    className="flex-grow resize-none shadow-sm focus:ring-secondary"
                                    rows={1}
                                    onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessageToDoctor(e);}}}
                                    />
                                    <Button type="submit" disabled={isSendingMessage || !newMessage.trim()} className="self-end bg-secondary hover:bg-secondary/90 h-auto py-2.5">
                                    {isSendingMessage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                                    </Button>
                                </form>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

              </motion.div>
            </Tabs>
          </motion.div>
        </div>
      );
    };

    export default PatientDashboardPage;
  
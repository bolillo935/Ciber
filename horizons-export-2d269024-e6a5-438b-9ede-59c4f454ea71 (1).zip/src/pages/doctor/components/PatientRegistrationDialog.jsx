
    import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
    import { Textarea } from '@/components/ui/textarea'; 
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Copy, CheckCircle } from 'lucide-react';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    export const PatientRegistrationDialog = ({ isOpen, onOpenChange, doctorId }) => {
        const [patientName, setPatientName] = useState('');
        const [initialNote, setInitialNote] = useState('');
        const [generatedCode, setGeneratedCode] = useState('');
        const [isCopied, setIsCopied] = useState(false);
        const [isGenerating, setIsGenerating] = useState(false);
        const [newlyCreatedPatientName, setNewlyCreatedPatientName] = useState('');
        const { toast } = useToast();

        const resetForm = () => {
            setPatientName('');
            setInitialNote('');
            setGeneratedCode('');
            setIsCopied(false);
            setNewlyCreatedPatientName('');
            setIsGenerating(false);
        };

        const handleOpenChange = (open) => {
            if (!open) {
                resetForm();
            }
            onOpenChange(open);
        };
        
        const generateAccessCodeInternal = () => {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let code = '';
            for (let i = 0; i < 7; i++) {
              code += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            return `ID-${code}`;
        };

        const handleGenerateCodeAndRegister = async () => {
            if (!patientName.trim()) {
              toast({ title: 'Error', description: 'Por favor, ingresa el nombre del paciente.', variant: 'destructive' });
              return;
            }
            setIsGenerating(true);
            setGeneratedCode('');
            setNewlyCreatedPatientName('');
            
            let newCode = generateAccessCodeInternal();
            let codeExists = true;
            let attempts = 0;
    
            while(codeExists && attempts < 10) {
              const { data: existingPatientCode, error: checkError } = await supabase.from('patients').select('access_code').eq('access_code', newCode).maybeSingle();
              if (checkError && checkError.code !== 'PGRST116') { 
                toast({ title: 'Error', description: 'Error al verificar el código: ' + checkError.message, variant: 'destructive' });
                setIsGenerating(false);
                return;
              }
              if (!existingPatientCode) {
                codeExists = false;
              } else {
                newCode = generateAccessCodeInternal(); 
              }
              attempts++;
            }
    
            if (codeExists) {
              toast({ title: 'Error', description: 'No se pudo generar un código único. Inténtalo de nuevo.', variant: 'destructive' });
              setIsGenerating(false);
              return;
            }
    
            const currentPatientName = patientName;
            const currentInitialNote = initialNote;

            const { data: newPatient, error: insertPatientError } = await supabase
              .from('patients')
              .insert([{ name: currentPatientName, access_code: newCode, doctor_id: doctorId }])
              .select()
              .single();
    
            if (insertPatientError) {
              toast({ title: 'Error', description: 'No se pudo crear el paciente: ' + insertPatientError.message, variant: 'destructive' });
              setIsGenerating(false);
              return;
            }

            if (newPatient) {
                 const { error: insertRecordError } = await supabase
                    .from('medical_records')
                    .insert([{
                        patient_id: newPatient.id,
                        doctor_id: doctorId,
                        title: 'Registro Inicial de Paciente',
                        content_type: 'text',
                        content_text: `Paciente registrado por el doctor. ${currentInitialNote ? `Nota inicial: ${currentInitialNote}` : 'Sin notas iniciales.'}`,
                        record_date: new Date().toISOString().split('T')[0] 
                    }]);
                
                if (insertRecordError) {
                    toast({ title: 'Advertencia', description: 'Paciente creado, pero hubo un error al guardar la nota inicial del expediente: ' + insertRecordError.message, variant: 'default' });
                }
            }
    
            setGeneratedCode(newCode);
            setNewlyCreatedPatientName(currentPatientName);
            toast({ title: 'Éxito', description: `Código de acceso generado para ${currentPatientName}.` });
            setIsGenerating(false);
        };
          
        const copyToClipboard = () => {
            if (!generatedCode) return;
            navigator.clipboard.writeText(generatedCode).then(() => {
              setIsCopied(true);
              toast({ title: 'Copiado', description: 'Código copiado al portapapeles.' });
              setTimeout(() => setIsCopied(false), 2000);
            });
        };

        return (
            <Dialog open={isOpen} onOpenChange={handleOpenChange}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>{generatedCode ? "Código Generado" : "Registrar Nuevo Paciente"}</DialogTitle>
                        {!generatedCode && (
                            <DialogDescription>
                                Ingresa los datos del paciente para generar un código de acceso y crear un mini expediente inicial.
                            </DialogDescription>
                        )}
                    </DialogHeader>
                    {!generatedCode ? (
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                                <Label htmlFor="patientNameDialog">Nombre del Paciente</Label>
                                <Input
                                    id="patientNameDialog"
                                    value={patientName}
                                    onChange={(e) => setPatientName(e.target.value)}
                                    placeholder="Nombre completo del paciente"
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="initialNoteDialog">Nota Inicial para Expediente (Opcional)</Label>
                                <Textarea
                                    id="initialNoteDialog"
                                    value={initialNote}
                                    onChange={(e) => setInitialNote(e.target.value)}
                                    placeholder="Ej: Paciente refiere alergia a la penicilina, motivo de consulta..."
                                    rows={3}
                                />
                            </div>
                        </div>
                    ) : (
                        <div className="py-4 text-center">
                            <p className="text-sm text-muted-foreground">Código de acceso para {newlyCreatedPatientName || 'el paciente'}:</p>
                            <div className="flex items-center justify-center space-x-2 mt-2">
                                <p className="text-2xl font-bold text-primary tracking-wider p-3 bg-primary/10 rounded-md">{generatedCode}</p>
                                <Button variant="ghost" size="icon" onClick={copyToClipboard} disabled={isCopied || !generatedCode}>
                                    {isCopied ? <CheckCircle className="h-5 w-5 text-green-500" /> : <Copy className="h-5 w-5" />}
                                </Button>
                            </div>
                             <p className="text-xs text-muted-foreground mt-3">Comparte este código con el paciente para que pueda acceder a su portal.</p>
                        </div>
                    )}
                    <DialogFooter>
                        {!generatedCode ? (
                            <Button onClick={handleGenerateCodeAndRegister} disabled={isGenerating || !patientName.trim()} className="w-full sm:w-auto">
                                {isGenerating ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generando y Registrando...</> : 'Generar Código y Registrar'}
                            </Button>
                        ) : (
                            <DialogClose asChild>
                                <Button type="button" variant="secondary" onClick={resetForm}>
                                    Cerrar
                                </Button>
                            </DialogClose>
                        )}
                         {isGenerating && !generatedCode && (
                             <Button type="button" variant="outline" onClick={resetForm} disabled={isGenerating}>
                                Cancelar
                            </Button>
                         )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    };
  

    import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Edit3, Trash2, PlusCircle } from 'lucide-react';
    import { DoctorAppointmentFormDialog } from './DoctorAppointmentFormDialog';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const AgendaView = ({ doctorId }) => {
      const [appointments, setAppointments] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const [isFormOpen, setIsFormOpen] = useState(false);
      const [selectedAppointment, setSelectedAppointment] = useState(null);
      const [patients, setPatients] = useState([]);
      const { toast } = useToast();

      const fetchDoctorPatients = useCallback(async () => {
        if (!doctorId) return;
        const { data, error } = await supabase
          .from('patients')
          .select('id, name')
          .eq('doctor_id', doctorId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los pacientes del doctor: ' + error.message, variant: 'destructive' });
          setPatients([]);
        } else {
          setPatients(data || []);
        }
      }, [doctorId, toast]);
      
      const fetchAppointments = useCallback(async () => {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('appointments')
          .select(`
            id, 
            start_time, 
            end_time, 
            status, 
            notes, 
            patient_id,
            patients (id, name)
          `)
          .eq('doctor_id', doctorId)
          .order('start_time', { ascending: true });

        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar las citas: ' + error.message, variant: 'destructive' });
          setAppointments([]);
        } else {
          setAppointments(data || []);
        }
        setIsLoading(false);
      }, [doctorId, toast]);

      useEffect(() => {
        fetchDoctorPatients();
        fetchAppointments();
      }, [fetchDoctorPatients, fetchAppointments]);

      const handleAppointmentSave = () => {
        fetchAppointments();
        setIsFormOpen(false);
        setSelectedAppointment(null);
      };

      const handleEditAppointment = (appointment) => {
        setSelectedAppointment(appointment);
        setIsFormOpen(true);
      };

      const handleDeleteAppointment = async (appointmentId) => {
        if (!window.confirm("¿Estás seguro de que quieres cancelar esta cita?")) return;
        
        const { error } = await supabase
          .from('appointments')
          .delete()
          .eq('id', appointmentId);

        if (error) {
          toast({ title: 'Error', description: 'No se pudo cancelar la cita: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Cita cancelada correctamente.' });
          fetchAppointments();
        }
      };
      
      if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando citas...</div>;

      return (
        <div className="space-y-4">
          <DoctorAppointmentFormDialog
            isOpen={isFormOpen}
            onOpenChange={setIsFormOpen}
            doctorId={doctorId}
            patients={patients}
            appointment={selectedAppointment}
            onSave={handleAppointmentSave}
          />
          <Button onClick={() => { setSelectedAppointment(null); setIsFormOpen(true); }} className="mt-4">
            <PlusCircle className="mr-2 h-4 w-4" /> Nueva Cita
          </Button>
          {!appointments.length && !isLoading && <p className="text-slate-500 mt-4">No tienes citas programadas.</p>}
          {appointments.map(app => (
            <Card key={app.id} className="overflow-hidden">
              <CardContent className="p-4">
                <CardTitle className="text-lg mb-1">{app.patients?.name || 'Paciente Desconocido'}</CardTitle>
                <CardDescription>
                  {new Date(app.start_time).toLocaleString([], {dateStyle: 'long', timeStyle: 'short'})} - {new Date(app.end_time).toLocaleTimeString([], {timeStyle: 'short'})}
                </CardDescription>
                <p className="text-sm text-muted-foreground mt-1">Estado: {app.status}</p>
                {app.notes && <p className="text-sm mt-1">Notas: {app.notes}</p>}
                 <div className="mt-2 flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEditAppointment(app)}><Edit3 className="h-4 w-4 mr-1" /> Editar</Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteAppointment(app.id)}><Trash2 className="h-4 w-4 mr-1" /> Cancelar</Button>
                  </div>
              </CardContent>
            </Card>
          ))}
        </div>
      );
    };

    export default AgendaView;
  
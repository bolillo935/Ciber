
    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    export const PrescriptionFormDialog = ({ isOpen, onOpenChange, doctorId, patientId, prescription, onSave }) => {
        const [medication, setMedication] = useState('');
        const [dosage, setDosage] = useState('');
        const [instructions, setInstructions] = useState('');
        const [duration, setDuration] = useState('');
        const [notes, setNotes] = useState('');
        const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0]);
        const [isSubmitting, setIsSubmitting] = useState(false);
        const { toast } = useToast();

        useEffect(() => {
            if (prescription) {
                setMedication(prescription.medication || '');
                setDosage(prescription.dosage || '');
                setInstructions(prescription.instructions || '');
                setDuration(prescription.duration || '');
                setNotes(prescription.notes || '');
                setIssueDate(prescription.issue_date ? new Date(prescription.issue_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
            } else {
                resetForm();
            }
        }, [prescription, isOpen]);

        const resetForm = () => {
            setMedication('');
            setDosage('');
            setInstructions('');
            setDuration('');
            setNotes('');
            setIssueDate(new Date().toISOString().split('T')[0]);
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            if (!medication.trim()) {
                toast({ title: "Error", description: "El medicamento es obligatorio.", variant: "destructive" });
                return;
            }
             if (!patientId) {
                toast({ title: "Error", description: "No se ha seleccionado un paciente.", variant: "destructive" });
                return;
            }


            setIsSubmitting(true);

            const prescriptionData = {
                patient_id: patientId,
                doctor_id: doctorId,
                medication,
                dosage,
                instructions,
                duration,
                notes,
                issue_date: issueDate,
            };
            
            let error;
            if (prescription?.id) {
                const { error: updateError } = await supabase
                    .from('prescriptions')
                    .update(prescriptionData)
                    .eq('id', prescription.id);
                error = updateError;
            } else {
                const { error: insertError } = await supabase
                    .from('prescriptions')
                    .insert(prescriptionData);
                error = insertError;
            }

            if (error) {
                toast({ title: "Error", description: (prescription?.id ? "No se pudo actualizar la receta: " : "No se pudo crear la receta: ") + error.message, variant: "destructive" });
            } else {
                toast({ title: "Éxito", description: `Receta ${prescription?.id ? "actualizada" : "creada"} correctamente.` });
                onSave();
                resetForm();
            }
            setIsSubmitting(false);
        };
        
        const handleClose = () => {
            if (!isSubmitting) {
                 resetForm();
                 onOpenChange(false);
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={handleClose}>
                <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle>{prescription?.id ? "Editar Receta" : "Nueva Receta"}</DialogTitle>
                        <DialogDescription>
                            {prescription?.id ? "Modifica los detalles de la receta." : "Crea una nueva receta para el paciente."}
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
                        <div>
                            <Label htmlFor="issueDate">Fecha de Emisión</Label>
                            <Input id="issueDate" type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="medication">Medicamento</Label>
                            <Input id="medication" value={medication} onChange={(e) => setMedication(e.target.value)} placeholder="Ej: Amoxicilina 500mg" disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="dosage">Dosis (Opcional)</Label>
                            <Input id="dosage" value={dosage} onChange={(e) => setDosage(e.target.value)} placeholder="Ej: 1 comprimido cada 8 horas" disabled={isSubmitting} />
                        </div>
                         <div>
                            <Label htmlFor="duration">Duración (Opcional)</Label>
                            <Input id="duration" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="Ej: 7 días, 1 mes" disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="instructions">Instrucciones (Opcional)</Label>
                            <Textarea id="instructions" value={instructions} onChange={(e) => setInstructions(e.target.value)} placeholder="Ej: Tomar con alimentos, evitar lácteos..." rows={3} disabled={isSubmitting}/>
                        </div>
                        <div>
                            <Label htmlFor="notes">Notas Adicionales (Opcional)</Label>
                            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Comentarios adicionales..." disabled={isSubmitting}/>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting || !patientId}>
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Guardando...</> : (prescription?.id ? "Guardar Cambios" : "Crear Receta")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        );
    };
  

    import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle } from 'lucide-react';
    import { FinanceTransactionFormDialog } from './FinanceTransactionFormDialog';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const FinanzasView = ({ doctorId }) => {
      const [transactions, setTransactions] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const [isFormOpen, setIsFormOpen] = useState(false);
      const { toast } = useToast();
    
      const fetchTransactions = useCallback(async () => {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('finances')
          .select('*')
          .eq('doctor_id', doctorId)
          .order('transaction_date', { ascending: false });
    
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar las transacciones: ' + error.message, variant: 'destructive' });
          setTransactions([]);
        } else {
          setTransactions(data || []);
        }
        setIsLoading(false);
      }, [doctorId, toast]);
    
      useEffect(() => {
        fetchTransactions();
      }, [fetchTransactions]);

      const handleSaveTransaction = () => {
        setIsFormOpen(false);
        fetchTransactions();
      }
    
      const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + parseFloat(t.amount), 0);
      const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + parseFloat(t.amount), 0);
      const balance = totalIncome - totalExpenses;
    
      if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando finanzas...</div>;
    
      return (
        <div>
          <FinanceTransactionFormDialog
            isOpen={isFormOpen}
            onOpenChange={setIsFormOpen}
            doctorId={doctorId}
            onSave={handleSaveTransaction}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardHeader><CardTitle>Ingresos Totales</CardTitle></CardHeader>
              <CardContent><p className="text-2xl font-bold text-green-600">${totalIncome.toFixed(2)}</p></CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Egresos Totales</CardTitle></CardHeader>
              <CardContent><p className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</p></CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Saldo Actual</CardTitle></CardHeader>
              <CardContent><p className={`text-2xl font-bold ${balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>${balance.toFixed(2)}</p></CardContent>
            </Card>
          </div>
          <Button onClick={() => setIsFormOpen(true)} className="mb-4"><PlusCircle className="mr-2 h-4 w-4" /> Nueva Transacción</Button>
          
          {!transactions.length && !isLoading && <p className="text-slate-500">No hay transacciones registradas.</p>}
          {transactions.length > 0 && (
            <div className="space-y-3">
              {transactions.map(t => (
                <Card key={t.id} className={t.type === 'income' ? 'border-l-4 border-l-green-500' : 'border-l-4 border-l-red-500'}>
                  <CardContent className="p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold">{t.description}</p>
                        <p className="text-sm text-muted-foreground">{new Date(t.transaction_date).toLocaleDateString()} - {t.category || 'Sin categoría'}</p>
                      </div>
                      <p className={`font-bold text-lg ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                        {t.type === 'income' ? '+' : '-'}${parseFloat(t.amount).toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      );
    };
    export default FinanzasView;
  
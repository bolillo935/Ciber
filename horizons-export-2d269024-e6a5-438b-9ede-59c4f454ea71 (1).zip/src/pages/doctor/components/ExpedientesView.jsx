
    import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Edit3, PlusCircle, Eye } from 'lucide-react';
    import { MedicalRecordFormDialog } from './MedicalRecordFormDialog';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const ExpedientesView = ({ doctorId }) => {
      const [patients, setPatients] = useState([]);
      const [selectedPatient, setSelectedPatient] = useState(null);
      const [records, setRecords] = useState([]);
      const [isLoadingPatients, setIsLoadingPatients] = useState(true);
      const [isLoadingRecords, setIsLoadingRecords] = useState(false);
      const [isFormOpen, setIsFormOpen] = useState(false);
      const [editingRecord, setEditingRecord] = useState(null);
      const { toast } = useToast();

      const fetchPatients = useCallback(async () => {
        setIsLoadingPatients(true);
        const { data, error } = await supabase
          .from('patients')
          .select('id, name')
          .eq('doctor_id', doctorId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los pacientes: ' + error.message, variant: 'destructive' });
          setPatients([]);
        } else {
          setPatients(data || []);
        }
        setIsLoadingPatients(false);
      }, [doctorId, toast]);

      useEffect(() => {
        fetchPatients();
      }, [fetchPatients]);

      const fetchRecords = useCallback(async (patientId) => {
        if (!patientId) {
          setRecords([]);
          setSelectedPatient(null);
          return;
        }
        setIsLoadingRecords(true);
        const patientDetails = patients.find(p => p.id === patientId);
        setSelectedPatient(patientDetails);

        const { data, error } = await supabase
          .from('medical_records')
          .select('*')
          .eq('patient_id', patientId)
          .eq('doctor_id', doctorId) 
          .order('record_date', { ascending: false });
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los expedientes: ' + error.message, variant: 'destructive' });
          setRecords([]);
        } else {
          setRecords(data || []);
        }
        setIsLoadingRecords(false);
      }, [doctorId, patients, toast]);
      
      const handleOpenFormForNew = () => {
        if (!selectedPatient) {
            toast({ title: "Seleccione un paciente", description: "Primero debe seleccionar un paciente.", variant: "default" });
            return;
        }
        setEditingRecord(null);
        setIsFormOpen(true);
      };

      const handleOpenFormForEdit = (record) => {
        setEditingRecord(record);
        setIsFormOpen(true);
      };

      const handleSaveRecord = () => {
        setIsFormOpen(false);
        setEditingRecord(null);
        if(selectedPatient) fetchRecords(selectedPatient.id);
      };

      if (isLoadingPatients) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando pacientes...</div>;

      return (
        <div>
          <MedicalRecordFormDialog
            isOpen={isFormOpen}
            onOpenChange={setIsFormOpen}
            doctorId={doctorId}
            patientId={selectedPatient?.id}
            record={editingRecord}
            onSave={handleSaveRecord}
          />

          <Label htmlFor="patient-select">Seleccionar Paciente:</Label>
          <select 
            id="patient-select"
            className="w-full p-2 border rounded-md mb-4 bg-white"
            onChange={(e) => fetchRecords(e.target.value)}
            disabled={!patients.length}
            value={selectedPatient?.id || ""}
          >
            <option value="">{patients.length ? "Selecciona un paciente" : "No hay pacientes asignados"}</option>
            {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>

          {selectedPatient && !isLoadingRecords && (
            <Button onClick={handleOpenFormForNew} className="mb-4">
              <PlusCircle className="mr-2 h-4 w-4" /> Nuevo Registro para {selectedPatient.name}
            </Button>
          )}

          {isLoadingRecords && <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando expedientes...</div>}
          
          {!isLoadingRecords && selectedPatient && !records.length && <p>No hay expedientes para {selectedPatient.name}.</p>}

          {!isLoadingRecords && records.length > 0 && (
            <div className="space-y-4">
              {records.map(rec => (
                <Card key={rec.id}>
                  <CardHeader>
                    <CardTitle>{rec.title || `Registro del ${new Date(rec.record_date).toLocaleDateString()}`}</CardTitle>
                    <CardDescription>Tipo: {rec.content_type}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {rec.content_text && <p className="whitespace-pre-wrap">{rec.content_text}</p>}
                    {rec.file_url && 
                        <a 
                            href={rec.file_url} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-500 hover:underline flex items-center"
                            onClick={(e) => {
                                e.preventDefault();
                                window.open(rec.file_url, '_blank');
                                toast({ title: 'Abriendo archivo...', description: 'Se está abriendo el archivo en una nueva pestaña.'});
                            }}
                        >
                           <Eye className="mr-1 h-4 w-4" /> Ver Archivo Adjunto ({rec.file_name})
                        </a>
                    }
                    {rec.notes && <p className="text-sm text-muted-foreground mt-2">Notas: {rec.notes}</p>}
                     <div className="mt-2 flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleOpenFormForEdit(rec)}><Edit3 className="h-4 w-4 mr-1" /> Editar</Button>
                      </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      );
    };

    export default ExpedientesView;
  

    import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle } from 'lucide-react';
    import { PrescriptionFormDialog } from './PrescriptionFormDialog';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const RecetasView = ({ doctorId }) => {
        const [patients, setPatients] = useState([]);
        const [selectedPatientId, setSelectedPatientId] = useState('');
        const [prescriptions, setPrescriptions] = useState([]);
        const [isLoadingPatients, setIsLoadingPatients] = useState(true);
        const [isLoadingPrescriptions, setIsLoadingPrescriptions] = useState(false);
        const [isFormOpen, setIsFormOpen] = useState(false);
        const { toast } = useToast();
      
        const fetchPatients = useCallback(async () => {
          setIsLoadingPatients(true);
          const { data, error } = await supabase
            .from('patients')
            .select('id, name')
            .eq('doctor_id', doctorId);
          if (error) {
            toast({ title: 'Error', description: 'No se pudieron cargar los pacientes: ' + error.message, variant: 'destructive' });
            setPatients([]);
          } else {
            setPatients(data || []);
          }
          setIsLoadingPatients(false);
        }, [doctorId, toast]);
        
        useEffect(() => {
          fetchPatients();
        }, [fetchPatients]);
      
        const fetchPrescriptions = useCallback(async (patientId) => {
          if (!patientId) {
            setPrescriptions([]);
            return;
          }
          setIsLoadingPrescriptions(true);
          const { data, error } = await supabase
            .from('prescriptions')
            .select('*')
            .eq('patient_id', patientId)
            .eq('doctor_id', doctorId)
            .order('issue_date', { ascending: false });
      
          if (error) {
            toast({ title: 'Error', description: 'No se pudieron cargar las recetas: ' + error.message, variant: 'destructive' });
            setPrescriptions([]);
          } else {
            setPrescriptions(data || []);
          }
          setIsLoadingPrescriptions(false);
        }, [doctorId, toast]);

        useEffect(() => {
            if(selectedPatientId) {
              fetchPrescriptions(selectedPatientId);
            } else {
              setPrescriptions([]);
            }
        }, [selectedPatientId, fetchPrescriptions]);

        const handleSavePrescription = () => {
          setIsFormOpen(false);
          if (selectedPatientId) {
            fetchPrescriptions(selectedPatientId);
          }
        };
      
        if (isLoadingPatients) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando pacientes...</div>;
      
        return (
          <div>
             <PrescriptionFormDialog
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                doctorId={doctorId}
                patientId={selectedPatientId}
                onSave={handleSavePrescription}
            />
            <div className="mb-4">
                <Label htmlFor="patient-prescription-select">Seleccionar Paciente:</Label>
                <select
                    id="patient-prescription-select"
                    value={selectedPatientId}
                    onChange={(e) => setSelectedPatientId(e.target.value)}
                    className="w-full p-2 border rounded-md bg-white"
                    disabled={!patients.length}
                >
                    <option value="">{patients.length ? "Selecciona un paciente" : "No hay pacientes"}</option>
                    {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
            </div>

            {selectedPatientId && (
                <Button onClick={() => setIsFormOpen(true)} className="mb-4">
                    <PlusCircle className="mr-2 h-4 w-4" /> Nueva Receta
                </Button>
            )}

            {isLoadingPrescriptions && <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /> Cargando recetas...</div>}
            
            {!isLoadingPrescriptions && selectedPatientId && !prescriptions.length && <p>No hay recetas para este paciente.</p>}

            {!isLoadingPrescriptions && prescriptions.length > 0 && (
                <div className="space-y-4">
                {prescriptions.map(presc => (
                    <Card key={presc.id}>
                    <CardHeader>
                        <CardTitle>Receta del {new Date(presc.issue_date).toLocaleDateString()}</CardTitle>
                        <CardDescription>Medicamento: {presc.medication}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p>Dosis: {presc.dosage}</p>
                        <p>Instrucciones: {presc.instructions}</p>
                        {presc.duration && <p>Duración: {presc.duration}</p>}
                        {presc.notes && <p className="text-sm text-muted-foreground mt-2">Notas: {presc.notes}</p>}
                        <Button size="sm" variant="outline" className="mt-2" onClick={() => alert(`Simulación: Descargando PDF de receta ID: ${presc.id}. En una app real, esto generaría y descargaría un PDF.`)}>Descargar (Simulado)</Button>
                    </CardContent>
                    </Card>
                ))}
                </div>
            )}
          </div>
        );
    };

    export default RecetasView;
  
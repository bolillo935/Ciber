
    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    export const MedicalRecordFormDialog = ({ isOpen, onOpenChange, doctorId, patientId, record, onSave }) => {
        const [title, setTitle] = useState('');
        const [contentType, setContentType] = useState('text');
        const [contentText, setContentText] = useState('');
        const [notes, setNotes] = useState('');
        const [recordDate, setRecordDate] = useState(new Date().toISOString().split('T')[0]);
        const [file, setFile] = useState(null);
        const [isSubmitting, setIsSubmitting] = useState(false);
        const { toast } = useToast();

        useEffect(() => {
            if (record) {
                setTitle(record.title || '');
                setContentType(record.content_type || 'text');
                setContentText(record.content_text || '');
                setNotes(record.notes || '');
                setRecordDate(record.record_date ? new Date(record.record_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
            } else {
                resetForm();
            }
        }, [record, isOpen]);

        const resetForm = () => {
            setTitle('');
            setContentType('text');
            setContentText('');
            setNotes('');
            setRecordDate(new Date().toISOString().split('T')[0]);
            setFile(null);
            if (document.getElementById('file_input')) {
                document.getElementById('file_input').value = '';
            }
        };

        const handleFileChange = (event) => {
            if (event.target.files && event.target.files[0]) {
                const selectedFile = event.target.files[0];
                 if (selectedFile.size > 5 * 1024 * 1024) { // 5MB limit
                    toast({ title: "Archivo muy grande", description: "El tamaño máximo del archivo es 5MB.", variant: "destructive" });
                    event.target.value = ""; 
                    setFile(null);
                    return;
                }
                setFile(selectedFile);
                setContentType(selectedFile.type.startsWith('image/') ? 'image' : 'file');
            }
        };
        
        const handleSubmit = async (e) => {
            e.preventDefault();
            if (!title.trim() && contentType === 'text' && !contentText.trim()) {
                toast({ title: "Error", description: "El título o el contenido son obligatorios para registros de texto.", variant: "destructive" });
                return;
            }
            if ((contentType === 'image' || contentType === 'file') && !file && !record?.file_url) {
                 toast({ title: "Error", description: "Debe seleccionar un archivo para tipo imagen o archivo.", variant: "destructive" });
                return;
            }

            setIsSubmitting(true);
            let fileUrl = record?.file_url || null;
            let fileName = record?.file_name || null;
            let fileMimeType = record?.file_type || null;

            if (file) {
                const filePath = `medical_records/${patientId}/${Date.now()}_${file.name}`;
                const { data: uploadData, error: uploadError } = await supabase.storage
                    .from('medical-files') 
                    .upload(filePath, file);

                if (uploadError) {
                    toast({ title: "Error de Carga", description: "No se pudo subir el archivo: " + uploadError.message, variant: "destructive" });
                    setIsSubmitting(false);
                    return;
                }
                
                const { data: publicUrlData } = supabase.storage.from('medical-files').getPublicUrl(filePath);
                fileUrl = publicUrlData.publicUrl;
                fileName = file.name;
                fileMimeType = file.type;
            }

            const recordData = {
                patient_id: patientId,
                doctor_id: doctorId,
                title: title.trim() || (contentType !== 'text' ? (fileName || 'Archivo Adjunto') : 'Registro sin título'),
                content_type: contentType,
                content_text: contentType === 'text' ? contentText : null,
                file_url: fileUrl,
                file_name: fileName,
                file_type: fileMimeType,
                notes,
                record_date: recordDate,
            };
            
            let error;
            if (record?.id) {
                const { error: updateError } = await supabase
                    .from('medical_records')
                    .update(recordData)
                    .eq('id', record.id);
                error = updateError;
            } else {
                const { error: insertError } = await supabase
                    .from('medical_records')
                    .insert(recordData);
                error = insertError;
            }

            if (error) {
                toast({ title: "Error", description: (record?.id ? "No se pudo actualizar el registro: " : "No se pudo crear el registro: ") + error.message, variant: "destructive" });
            } else {
                toast({ title: "Éxito", description: `Registro médico ${record?.id ? "actualizado" : "creado"} correctamente.` });
                onSave();
                resetForm();
            }
            setIsSubmitting(false);
        };

        const handleClose = () => {
            if (!isSubmitting) {
                resetForm();
                onOpenChange(false);
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={handleClose}>
                <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle>{record?.id ? "Editar Registro Médico" : "Nuevo Registro Médico"}</DialogTitle>
                        <DialogDescription>
                            {record?.id ? "Modifica los detalles del registro." : "Añade un nuevo registro al expediente del paciente."}
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
                        <div>
                            <Label htmlFor="recordDate">Fecha del Registro</Label>
                            <Input id="recordDate" type="date" value={recordDate} onChange={(e) => setRecordDate(e.target.value)} disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="title">Título (Opcional para archivos)</Label>
                            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ej: Consulta de seguimiento, Radiografía panorámica" disabled={isSubmitting} />
                        </div>
                         <div>
                            <Label htmlFor="contentType">Tipo de Contenido</Label>
                            <select 
                                id="contentType" 
                                value={contentType} 
                                onChange={(e) => {setContentType(e.target.value); if(e.target.value === 'text') setFile(null); }}
                                className="w-full p-2 border rounded-md bg-white"
                                disabled={isSubmitting || (!!file && (contentType === 'image' || contentType === 'file'))}
                            >
                                <option value="text">Nota de Texto</option>
                                <option value="image">Imagen</option>
                                <option value="file">Archivo (PDF, Documento, etc.)</option>
                            </select>
                        </div>

                        {contentType === 'text' && (
                            <div>
                                <Label htmlFor="contentText">Contenido del Registro</Label>
                                <Textarea id="contentText" value={contentText} onChange={(e) => setContentText(e.target.value)} placeholder="Detalles del registro, observaciones, diagnóstico..." rows={5} disabled={isSubmitting} />
                            </div>
                        )}

                        {(contentType === 'image' || contentType === 'file') && (
                            <div>
                                <Label htmlFor="file_input">Archivo</Label>
                                <Input id="file_input" type="file" onChange={handleFileChange} disabled={isSubmitting} accept={contentType === 'image' ? 'image/*' : '*/*'} />
                                {record?.file_url && !file && <p className="text-xs mt-1 text-muted-foreground">Archivo actual: {record.file_name}. Selecciona uno nuevo para reemplazarlo.</p>}
                            </div>
                        )}
                        <div>
                            <Label htmlFor="notes">Notas Adicionales (Opcional)</Label>
                            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Comentarios adicionales..." disabled={isSubmitting}/>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Guardando...</> : (record?.id ? "Guardar Cambios" : "Crear Registro")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        );
    };
  

    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    export const DoctorAppointmentFormDialog = ({ isOpen, onOpenChange, doctorId, patients, appointment, onSave }) => {
        const [patientId, setPatientId] = useState('');
        const [startTime, setStartTime] = useState('');
        const [endTime, setEndTime] = useState('');
        const [status, setStatus] = useState('scheduled');
        const [notes, setNotes] = useState('');
        const [isSubmitting, setIsSubmitting] = useState(false);
        const { toast } = useToast();

        useEffect(() => {
            if (appointment) {
                setPatientId(appointment.patient_id || '');
                setStartTime(appointment.start_time ? new Date(appointment.start_time).toISOString().slice(0, 16) : '');
                setEndTime(appointment.end_time ? new Date(appointment.end_time).toISOString().slice(0, 16) : '');
                setStatus(appointment.status || 'scheduled');
                setNotes(appointment.notes || '');
            } else {
                resetForm();
            }
        }, [appointment, isOpen]);

        const resetForm = () => {
            setPatientId('');
            setStartTime('');
            setEndTime('');
            setStatus('scheduled');
            setNotes('');
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            if (!patientId || !startTime || !endTime) {
                toast({ title: "Error", description: "Paciente, hora de inicio y hora de fin son obligatorios.", variant: "destructive" });
                return;
            }
            if (new Date(endTime) <= new Date(startTime)) {
                toast({ title: "Error", description: "La hora de fin debe ser posterior a la hora de inicio.", variant: "destructive" });
                return;
            }

            setIsSubmitting(true);

            const appointmentData = {
                doctor_id: doctorId,
                patient_id: patientId,
                start_time: new Date(startTime).toISOString(),
                end_time: new Date(endTime).toISOString(),
                status,
                notes,
            };
            
            let error;
            if (appointment?.id) {
                const { error: updateError } = await supabase
                    .from('appointments')
                    .update(appointmentData)
                    .eq('id', appointment.id);
                error = updateError;
            } else {
                const { error: insertError } = await supabase
                    .from('appointments')
                    .insert(appointmentData);
                error = insertError;
            }

            if (error) {
                toast({ title: "Error", description: (appointment?.id ? "No se pudo actualizar la cita: " : "No se pudo crear la cita: ") + error.message, variant: "destructive" });
            } else {
                toast({ title: "Éxito", description: `Cita ${appointment?.id ? "actualizada" : "creada"} correctamente.` });
                onSave();
                resetForm(); 
            }
            setIsSubmitting(false);
        };
        
        const handleClose = () => {
            if (!isSubmitting) {
                 resetForm();
                 onOpenChange(false);
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={handleClose}>
                <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle>{appointment?.id ? "Editar Cita" : "Nueva Cita"}</DialogTitle>
                        <DialogDescription>
                            {appointment?.id ? "Modifica los detalles de la cita." : "Programa una nueva cita para un paciente."}
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
                        <div>
                            <Label htmlFor="patient">Paciente</Label>
                            <select 
                                id="patient" 
                                value={patientId} 
                                onChange={(e) => setPatientId(e.target.value)}
                                className="w-full p-2 border rounded-md bg-white"
                                disabled={!patients.length || isSubmitting}
                            >
                                <option value="">{patients.length ? "Selecciona un paciente" : "No hay pacientes registrados"}</option>
                                {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                            </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="startTime">Hora de Inicio</Label>
                                <Input id="startTime" type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} disabled={isSubmitting} />
                            </div>
                            <div>
                                <Label htmlFor="endTime">Hora de Fin</Label>
                                <Input id="endTime" type="datetime-local" value={endTime} onChange={(e) => setEndTime(e.target.value)} disabled={isSubmitting} />
                            </div>
                        </div>
                        <div>
                            <Label htmlFor="status">Estado</Label>
                             <select 
                                id="status" 
                                value={status} 
                                onChange={(e) => setStatus(e.target.value)}
                                className="w-full p-2 border rounded-md bg-white"
                                disabled={isSubmitting}
                            >
                                <option value="scheduled">Programada</option>
                                <option value="confirmed">Confirmada</option>
                                <option value="completed">Completada</option>
                                <option value="cancelled_by_doctor">Cancelada por Doctor</option>
                                <option value="cancelled_by_patient">Cancelada por Paciente</option>
                                <option value="rescheduled">Reprogramada</option>
                            </select>
                        </div>
                        <div>
                            <Label htmlFor="notes">Notas (Opcional)</Label>
                            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notas adicionales sobre la cita..." disabled={isSubmitting}/>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Guardando...</> : (appointment?.id ? "Guardar Cambios" : "Crear Cita")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        );
    };
  
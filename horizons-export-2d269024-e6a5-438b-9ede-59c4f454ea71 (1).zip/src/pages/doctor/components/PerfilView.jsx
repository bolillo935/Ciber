
    import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { useAuth } from '@/contexts/AuthContext';
    import { Edit3 } from 'lucide-react';

    const PerfilView = ({ doctor }) => {
        const [name, setName] = useState(doctor.name);
        const [specialty, setSpecialty] = useState(doctor.specialty);
        const [isEditing, setIsEditing] = useState(false);
        const { toast } = useToast();
        const { user: authUser, refreshUserProfile } = useAuth(); 

        const handleSaveProfile = async () => {
            if(!name.trim() || !specialty.trim()){
                toast({title: "Error", description: "Nombre y especialidad no pueden estar vacíos.", variant: "destructive"});
                return;
            }
            const { error } = await supabase
                .from('doctors')
                .update({ name, specialty })
                .eq('id', doctor.id);

            if(error){
                toast({title: "Error", description: "No se pudo actualizar el perfil: " + error.message, variant: "destructive"});
            } else {
                toast({title: "Éxito", description: "Perfil actualizado."});
                setIsEditing(false);
                if(refreshUserProfile) refreshUserProfile(); 
            }
        }

        return (
            <Card>
                <CardHeader>
                    <CardTitle>Tu Perfil Profesional</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label htmlFor="doctorName">Nombre</Label>
                        <Input id="doctorName" value={name} onChange={(e) => setName(e.target.value)} disabled={!isEditing} />
                    </div>
                    <div>
                        <Label htmlFor="doctorSpecialty">Especialidad</Label>
                        <Input id="doctorSpecialty" value={specialty} onChange={(e) => setSpecialty(e.target.value)} disabled={!isEditing} />
                    </div>
                    <div>
                        <Label>Email (no editable)</Label>
                        <Input value={authUser.email} disabled />
                    </div>
                    <div className="text-sm text-muted-foreground">La carga de foto de perfil y otros campos estarán disponibles próximamente.</div>
                    
                    {isEditing ? (
                        <div className="flex gap-2">
                            <Button onClick={handleSaveProfile}>Guardar Cambios</Button>
                            <Button variant="outline" onClick={() => {
                                setName(doctor.name);
                                setSpecialty(doctor.specialty);
                                setIsEditing(false);
                            }}>Cancelar</Button>
                        </div>
                    ) : (
                        <Button onClick={() => setIsEditing(true)}><Edit3 className="mr-2 h-4 w-4"/>Editar Perfil</Button>
                    )}
                </CardContent>
            </Card>
        );
    };
    export default PerfilView;
  

    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Checkbox } from '@/components/ui/checkbox';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    export const PromotionFormDialog = ({ isOpen, onOpenChange, publisherId, publisherType, promotion, onSave }) => {
        const [title, setTitle] = useState('');
        const [description, setDescription] = useState('');
        const [startDate, setStartDate] = useState('');
        const [endDate, setEndDate] = useState('');
        const [isActive, setIsActive] = useState(true);
        const [isSubmitting, setIsSubmitting] = useState(false);
        const { toast } = useToast();

        useEffect(() => {
            if (promotion) {
                setTitle(promotion.title || '');
                setDescription(promotion.description || '');
                setStartDate(promotion.start_date ? new Date(promotion.start_date).toISOString().split('T')[0] : '');
                setEndDate(promotion.end_date ? new Date(promotion.end_date).toISOString().split('T')[0] : '');
                setIsActive(promotion.is_active !== undefined ? promotion.is_active : true);
            } else {
                resetForm();
            }
        }, [promotion, isOpen]);

        const resetForm = () => {
            setTitle('');
            setDescription('');
            setStartDate('');
            setEndDate('');
            setIsActive(true);
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            if (!title.trim()) {
                toast({ title: "Error", description: "El título de la promoción es obligatorio.", variant: "destructive" });
                return;
            }
            if (startDate && endDate && new Date(endDate) < new Date(startDate)) {
                toast({ title: "Error", description: "La fecha de fin no puede ser anterior a la fecha de inicio.", variant: "destructive" });
                return;
            }

            setIsSubmitting(true);

            const promotionData = {
                publisher_id: publisherId,
                publisher_type: publisherType,
                title,
                description: description.trim() || null,
                start_date: startDate || null,
                end_date: endDate || null,
                is_active: isActive,
                target_audience: publisherType === 'doctor' ? 'all_patients_of_doctor' : 'all_patients_of_clinic', // Default, can be expanded
            };
            
            let error;
            if (promotion?.id) {
                const { error: updateError } = await supabase
                    .from('promotions')
                    .update(promotionData)
                    .eq('id', promotion.id);
                error = updateError;
            } else {
                const { error: insertError } = await supabase
                    .from('promotions')
                    .insert(promotionData);
                error = insertError;
            }

            if (error) {
                toast({ title: "Error", description: (promotion?.id ? "No se pudo actualizar la promoción: " : "No se pudo crear la promoción: ") + error.message, variant: "destructive" });
            } else {
                toast({ title: "Éxito", description: `Promoción ${promotion?.id ? "actualizada" : "creada"} correctamente.` });
                onSave();
                resetForm();
            }
            setIsSubmitting(false);
        };
        
        const handleClose = () => {
            if (!isSubmitting) {
                resetForm();
                onOpenChange(false);
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={handleClose}>
                <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle>{promotion?.id ? "Editar Promoción" : "Nueva Promoción/Anuncio"}</DialogTitle>
                        <DialogDescription>
                            {promotion?.id ? "Modifica los detalles." : "Crea una nueva promoción o anuncio."}
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
                        <div>
                            <Label htmlFor="promoTitle">Título</Label>
                            <Input id="promoTitle" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ej: Descuento en Limpieza Dental" disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="promoDescription">Descripción (Opcional)</Label>
                            <Textarea id="promoDescription" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detalles de la promoción..." rows={3} disabled={isSubmitting}/>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="promoStartDate">Fecha de Inicio (Opcional)</Label>
                                <Input id="promoStartDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} disabled={isSubmitting} />
                            </div>
                            <div>
                                <Label htmlFor="promoEndDate">Fecha de Fin (Opcional)</Label>
                                <Input id="promoEndDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} disabled={isSubmitting} min={startDate || undefined} />
                            </div>
                        </div>
                        <div className="flex items-center space-x-2">
                            <Checkbox id="promoIsActive" checked={isActive} onCheckedChange={setIsActive} disabled={isSubmitting}/>
                            <Label htmlFor="promoIsActive" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                Activa
                            </Label>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Guardando...</> : (promotion?.id ? "Guardar Cambios" : "Crear Promoción")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        );
    };
  

    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    export const FinanceTransactionFormDialog = ({ isOpen, onOpenChange, doctorId, transaction, onSave }) => {
        const [type, setType] = useState('income');
        const [description, setDescription] = useState('');
        const [amount, setAmount] = useState('');
        const [category, setCategory] = useState('');
        const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
        const [isSubmitting, setIsSubmitting] = useState(false);
        const { toast } = useToast();

        useEffect(() => {
            if (transaction) {
                setType(transaction.type || 'income');
                setDescription(transaction.description || '');
                setAmount(transaction.amount?.toString() || '');
                setCategory(transaction.category || '');
                setTransactionDate(transaction.transaction_date ? new Date(transaction.transaction_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
            } else {
                resetForm();
            }
        }, [transaction, isOpen]);

        const resetForm = () => {
            setType('income');
            setDescription('');
            setAmount('');
            setCategory('');
            setTransactionDate(new Date().toISOString().split('T')[0]);
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            if (!description.trim() || !amount.trim() || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
                toast({ title: "Error", description: "Descripción y monto válido son obligatorios.", variant: "destructive" });
                return;
            }

            setIsSubmitting(true);

            const transactionData = {
                doctor_id: doctorId,
                type,
                description,
                amount: parseFloat(amount),
                category: category.trim() || null,
                transaction_date: transactionDate,
            };
            
            let error;
            if (transaction?.id) {
                const { error: updateError } = await supabase
                    .from('finances')
                    .update(transactionData)
                    .eq('id', transaction.id);
                error = updateError;
            } else {
                const { error: insertError } = await supabase
                    .from('finances')
                    .insert(transactionData);
                error = insertError;
            }

            if (error) {
                toast({ title: "Error", description: (transaction?.id ? "No se pudo actualizar la transacción: " : "No se pudo crear la transacción: ") + error.message, variant: "destructive" });
            } else {
                toast({ title: "Éxito", description: `Transacción ${transaction?.id ? "actualizada" : "creada"} correctamente.` });
                onSave();
                resetForm();
            }
            setIsSubmitting(false);
        };
        
        const handleClose = () => {
            if (!isSubmitting) {
                resetForm();
                onOpenChange(false);
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={handleClose}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>{transaction?.id ? "Editar Transacción" : "Nueva Transacción"}</DialogTitle>
                        <DialogDescription>
                            {transaction?.id ? "Modifica los detalles de la transacción." : "Registra un nuevo ingreso o egreso."}
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
                        <div>
                            <Label htmlFor="transactionDate">Fecha</Label>
                            <Input id="transactionDate" type="date" value={transactionDate} onChange={(e) => setTransactionDate(e.target.value)} disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="type">Tipo</Label>
                            <select 
                                id="type" 
                                value={type} 
                                onChange={(e) => setType(e.target.value)}
                                className="w-full p-2 border rounded-md bg-white"
                                disabled={isSubmitting}
                            >
                                <option value="income">Ingreso</option>
                                <option value="expense">Egreso</option>
                            </select>
                        </div>
                        <div>
                            <Label htmlFor="description">Descripción</Label>
                            <Input id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ej: Consulta Paciente X, Compra de guantes" disabled={isSubmitting} />
                        </div>
                        <div>
                            <Label htmlFor="amount">Monto</Label>
                            <Input id="amount" type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Ej: 150.00" disabled={isSubmitting} />
                        </div>
                         <div>
                            <Label htmlFor="category">Categoría (Opcional)</Label>
                            <Input id="category" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Ej: Consultas, Suministros, Alquiler" disabled={isSubmitting} />
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Guardando...</> : (transaction?.id ? "Guardar Cambios" : "Crear Transacción")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        );
    };
  
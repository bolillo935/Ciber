
    import React, { useState, useEffect, useRef } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle, Edit3, Trash2, Loader2, CalendarPlus as CalendarIcon } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import FullCalendar from '@fullcalendar/react';
    import dayGridPlugin from '@fullcalendar/daygrid';
    import timeGridPlugin from '@fullcalendar/timegrid';
    import interactionPlugin from '@fullcalendar/interaction';
    import { formatISO, parseISO } from 'date-fns';

    const AppointmentsCalendarTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [events, setEvents] = useState([]);
      const [isLoading, setIsLoading] = useState(false);
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [currentAppointment, setCurrentAppointment] = useState({ patient_id: '', start_time: '', end_time: '', notes: '', title: '' });
      const [patientsForSelect, setPatientsForSelect] = useState([]);
      const [editingAppointmentId, setEditingAppointmentId] = useState(null);
      const calendarRef = useRef(null);

      useEffect(() => {
        if (user && user.id) {
          fetchAppointments();
          fetchPatientsForSelect();
        }
      }, [user]);

      const fetchAppointments = async () => {
        if (!user || !user.id) return;
        setIsLoading(true);
        const { data, error } = await supabase
          .from('appointments')
          .select('id, start_time, end_time, notes, patient_id, patients (name)')
          .eq('doctor_id', user.id);

        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar las citas: ' + error.message, variant: 'destructive' });
        } else {
          const formattedEvents = data.map(app => ({
            id: app.id,
            title: app.patients?.name || 'Cita',
            start: app.start_time,
            end: app.end_time,
            extendedProps: {
              notes: app.notes,
              patient_id: app.patient_id,
              patient_name: app.patients?.name
            }
          }));
          setEvents(formattedEvents);
        }
        setIsLoading(false);
      };
      
      const fetchPatientsForSelect = async () => {
        if (!user || !user.id) return;
        const { data, error } = await supabase
          .from('patients')
          .select('id, name')
          .eq('doctor_id', user.id);
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los pacientes: ' + error.message, variant: 'destructive' });
        } else {
          setPatientsForSelect(data);
        }
      };

      const handleDialogSubmit = async (e) => {
        e.preventDefault();
        if (!currentAppointment.patient_id || !currentAppointment.start_time || !currentAppointment.end_time) {
          toast({ title: 'Error', description: 'Paciente, hora de inicio y fin son requeridos.', variant: 'destructive' });
          return;
        }

        const appointmentData = {
          doctor_id: user.id,
          patient_id: currentAppointment.patient_id,
          start_time: formatISO(parseISO(currentAppointment.start_time)),
          end_time: formatISO(parseISO(currentAppointment.end_time)),
          status: 'CONFIRMED',
          notes: currentAppointment.notes,
        };

        let result;
        if (editingAppointmentId) {
          result = await supabase.from('appointments').update(appointmentData).eq('id', editingAppointmentId).select();
        } else {
          result = await supabase.from('appointments').insert(appointmentData).select();
        }

        if (result.error) {
          toast({ title: 'Error', description: `No se pudo ${editingAppointmentId ? 'actualizar' : 'crear'} la cita: ` + result.error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Cita ${editingAppointmentId ? 'actualizada' : 'creada'} correctamente.` });
          setIsDialogOpen(false);
          fetchAppointments();
        }
      };
      
      const handleEventClick = (clickInfo) => {
        const { event } = clickInfo;
        setEditingAppointmentId(event.id);
        setCurrentAppointment({
          patient_id: event.extendedProps.patient_id,
          start_time: formatISO(event.start).slice(0, 16),
          end_time: formatISO(event.end).slice(0, 16),
          notes: event.extendedProps.notes || '',
          title: event.title
        });
        setIsDialogOpen(true);
      };

      const handleDateSelect = (selectInfo) => {
        setEditingAppointmentId(null);
        setCurrentAppointment({
          patient_id: '',
          start_time: formatISO(selectInfo.start).slice(0, 16),
          end_time: formatISO(selectInfo.end).slice(0, 16),
          notes: '',
          title: ''
        });
        setIsDialogOpen(true);
        if (calendarRef.current) {
            calendarRef.current.getApi().unselect();
        }
      };

      const handleDelete = async () => {
        if (!editingAppointmentId) return;
        if (!window.confirm("¿Estás seguro de que quieres eliminar esta cita?")) return;
        
        const { error } = await supabase.from('appointments').delete().eq('id', editingAppointmentId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar la cita: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Cita eliminada.' });
          setIsDialogOpen(false);
          fetchAppointments();
          setEditingAppointmentId(null);
        }
      };

      return (
        <Card className="shadow-xl p-2 md:p-4">
          <CardHeader className="pb-2 md:pb-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
              <CardTitle className="text-2xl font-semibold text-primary mb-2 sm:mb-0">Agenda Interactiva</CardTitle>
              <Button onClick={() => { setEditingAppointmentId(null); setCurrentAppointment({ patient_id: '', start_time: '', end_time: '', notes: '', title: '' }); setIsDialogOpen(true); }} className="bg-primary hover:bg-primary/90">
                <PlusCircle className="mr-2 h-5 w-5" /> Nueva Cita
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
              <div className="fc-wrapper" style={{ minHeight: '600px' }}>
                <FullCalendar
                  ref={calendarRef}
                  plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                  headerToolbar={{
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                  }}
                  initialView="timeGridWeek"
                  editable={true}
                  selectable={true}
                  selectMirror={true}
                  dayMaxEvents={true}
                  weekends={true}
                  events={events}
                  select={handleDateSelect}
                  eventClick={handleEventClick}
                  locale="es"
                  buttonText={{
                    today:    'Hoy',
                    month:    'Mes',
                    week:     'Semana',
                    day:      'Día',
                  }}
                  allDaySlot={false}
                  slotMinTime="08:00:00"
                  slotMaxTime="21:00:00"
                  height="auto" 
                />
              </div>
            )}
          </CardContent>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>{editingAppointmentId ? `Editar Cita: ${currentAppointment.title}` : 'Nueva Cita'}</DialogTitle>
                <DialogDescription>
                  {editingAppointmentId ? 'Modifica los detalles de la cita.' : 'Completa los detalles para agendar una nueva cita.'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleDialogSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="space-y-1">
                    <Label htmlFor="patient_id">Paciente</Label>
                    <select 
                      id="patient_id" 
                      value={currentAppointment.patient_id}
                      onChange={(e) => setCurrentAppointment({...currentAppointment, patient_id: e.target.value})}
                      className="w-full p-2 border rounded-md bg-white"
                      required
                    >
                      <option value="" disabled>Selecciona un paciente</option>
                      {patientsForSelect.map(p => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="start_time">Inicio</Label>
                    <Input id="start_time" type="datetime-local" value={currentAppointment.start_time} onChange={(e) => setCurrentAppointment({...currentAppointment, start_time: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="end_time">Fin</Label>
                    <Input id="end_time" type="datetime-local" value={currentAppointment.end_time} onChange={(e) => setCurrentAppointment({...currentAppointment, end_time: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="notes">Notas</Label>
                    <Input id="notes" value={currentAppointment.notes} onChange={(e) => setCurrentAppointment({...currentAppointment, notes: e.target.value})} placeholder="Notas adicionales (opcional)" />
                  </div>
                </div>
                <DialogFooter className="flex justify-between items-center">
                  <div>
                    {editingAppointmentId && (
                      <Button type="button" variant="destructive" onClick={handleDelete} className="mr-auto">
                        <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                      </Button>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                    <Button type="submit" className="bg-primary hover:bg-primary/90">
                      {editingAppointmentId ? 'Actualizar Cita' : 'Crear Cita'}
                    </Button>
                  </div>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      );
    };

    export default AppointmentsCalendarTab;
  
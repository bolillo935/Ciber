
    import React, { useState, useEffect } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle, Edit3, Trash2, Loader2 } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const AppointmentsTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [appointments, setAppointments] = useState([]);
      const [isLoading, setIsLoading] = useState(false);
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [currentAppointment, setCurrentAppointment] = useState({ patient_id: '', start_time: '', notes: '' });
      const [patientsForSelect, setPatientsForSelect] = useState([]);
      const [editingAppointment, setEditingAppointment] = useState(null);

      useEffect(() => {
        if (user && user.id) {
          fetchAppointments();
          fetchPatientsForSelect();
        }
      }, [user]);

      const fetchAppointments = async () => {
        if (!user || !user.id) return;
        setIsLoading(true);
        const { data, error } = await supabase
          .from('appointments')
          .select(`
            *,
            patients (id, name)
          `)
          .eq('doctor_id', user.id)
          .order('start_time', { ascending: true });

        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar las citas: ' + error.message, variant: 'destructive' });
        } else {
          setAppointments(data);
        }
        setIsLoading(false);
      };
      
      const fetchPatientsForSelect = async () => {
        if (!user || !user.id) return;
        const { data, error } = await supabase
          .from('patients')
          .select('id, name')
          .eq('doctor_id', user.id);
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los pacientes: ' + error.message, variant: 'destructive' });
        } else {
          setPatientsForSelect(data);
        }
      };

      const handleDialogSubmit = async (e) => {
        e.preventDefault();
        if (!currentAppointment.patient_id || !currentAppointment.start_time) {
          toast({ title: 'Error', description: 'Paciente y fecha/hora son requeridos.', variant: 'destructive' });
          return;
        }

        const appointmentData = {
          doctor_id: user.id,
          patient_id: currentAppointment.patient_id,
          start_time: currentAppointment.start_time,
          end_time: new Date(new Date(currentAppointment.start_time).getTime() + 60 * 60 * 1000).toISOString(), // Example: 1 hour duration
          status: 'CONFIRMED',
          notes: currentAppointment.notes,
        };

        let result;
        if (editingAppointment) {
          result = await supabase.from('appointments').update(appointmentData).eq('id', editingAppointment.id).select();
        } else {
          result = await supabase.from('appointments').insert(appointmentData).select();
        }

        if (result.error) {
          toast({ title: 'Error', description: `No se pudo ${editingAppointment ? 'actualizar' : 'crear'} la cita: ` + result.error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Cita ${editingAppointment ? 'actualizada' : 'creada'} correctamente.` });
          setIsDialogOpen(false);
          fetchAppointments();
        }
      };
      
      const openEditDialog = (appointment) => {
        setEditingAppointment(appointment);
        setCurrentAppointment({
          patient_id: appointment.patient_id,
          start_time: new Date(appointment.start_time).toISOString().slice(0, 16),
          notes: appointment.notes || ''
        });
        setIsDialogOpen(true);
      };

      const openNewDialog = () => {
        setEditingAppointment(null);
        setCurrentAppointment({ patient_id: '', start_time: '', notes: '' });
        setIsDialogOpen(true);
      };

      const handleDelete = async (appointmentId) => {
        if (!window.confirm("¿Estás seguro de que quieres eliminar esta cita?")) return;
        const { error } = await supabase.from('appointments').delete().eq('id', appointmentId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar la cita: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Cita eliminada.' });
          fetchAppointments();
        }
      };

      return (
        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl font-semibold text-primary">Agenda de Citas</CardTitle>
              <Button onClick={openNewDialog} className="bg-primary hover:bg-primary/90">
                <PlusCircle className="mr-2 h-5 w-5" /> Nueva Cita
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <div className="flex justify-center items-center p-6"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
              appointments.length > 0 ? (
                <ul className="space-y-4">
                  {appointments.map(app => (
                    <li key={app.id} className="p-4 border bg-slate-50 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center shadow-sm hover:shadow-md transition-shadow">
                      <div className="mb-2 sm:mb-0">
                        <p className="font-semibold text-slate-800 text-lg">{app.patients?.name || 'Paciente no encontrado'}</p>
                        <p className="text-sm text-slate-600">{new Date(app.start_time).toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' })}</p>
                        {app.notes && <p className="text-xs text-slate-500 mt-1">Notas: {app.notes}</p>}
                      </div>
                      <div className="flex space-x-2 self-end sm:self-center">
                        <Button variant="outline" size="sm" onClick={() => openEditDialog(app)}><Edit3 className="h-4 w-4 mr-1 sm:mr-0"/> <span className="sm:hidden ml-1">Editar</span></Button>
                        <Button variant="destructive" size="sm" onClick={() => handleDelete(app.id)}><Trash2 className="h-4 w-4 mr-1 sm:mr-0"/> <span className="sm:hidden ml-1">Eliminar</span></Button>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : <p className="text-slate-500 text-center py-4">No hay citas programadas.</p>
            )}
          </CardContent>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[480px]">
              <DialogHeader>
                <DialogTitle>{editingAppointment ? 'Editar Cita' : 'Nueva Cita'}</DialogTitle>
                <DialogDescription>
                  {editingAppointment ? 'Modifica los detalles de la cita.' : 'Completa los detalles para agendar una nueva cita.'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleDialogSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="patient_id" className="text-right col-span-1">Paciente</Label>
                    <select 
                      id="patient_id" 
                      value={currentAppointment.patient_id}
                      onChange={(e) => setCurrentAppointment({...currentAppointment, patient_id: e.target.value})}
                      className="col-span-3 p-2 border rounded-md bg-white"
                      required
                    >
                      <option value="" disabled>Selecciona un paciente</option>
                      {patientsForSelect.map(p => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="start_time" className="text-right col-span-1">Fecha y Hora</Label>
                    <Input
                      id="start_time"
                      type="datetime-local"
                      value={currentAppointment.start_time}
                      onChange={(e) => setCurrentAppointment({...currentAppointment, start_time: e.target.value})}
                      className="col-span-3"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="notes" className="text-right col-span-1">Notas</Label>
                    <Input
                      id="notes"
                      value={currentAppointment.notes}
                      onChange={(e) => setCurrentAppointment({...currentAppointment, notes: e.target.value})}
                      className="col-span-3"
                      placeholder="Notas adicionales (opcional)"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">
                    {editingAppointment ? 'Actualizar Cita' : 'Crear Cita'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      );
    };

    export default AppointmentsTab;
  

    import React, { useState, useEffect, useRef } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Send, Loader2, UserCircle, MessageSquare, Smile } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { formatDistanceToNow, parseISO } from 'date-fns';
    import { es } from 'date-fns/locale';

    const MessagesTabDoctor = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [patients, setPatients] = useState([]);
      const [selectedPatient, setSelectedPatient] = useState(null);
      const [messages, setMessages] = useState([]);
      const [newMessage, setNewMessage] = useState('');
      const [isLoadingMessages, setIsLoadingMessages] = useState(false);
      const [isSending, setIsSending] = useState(false);
      const messagesEndRef = useRef(null);
      const [searchTerm, setSearchTerm] = useState('');

      useEffect(() => {
        if (user && user.id) {
          fetchPatientsForSelect();
        }
      }, [user]);

      useEffect(() => {
        if (selectedPatient) {
          fetchMessages();
          const channel = supabase
            .channel(`messages:doctor-${user.id}:patient-${selectedPatient.id}`)
            .on('postgres_changes', { 
                event: 'INSERT', 
                schema: 'public', 
                table: 'messages',
                filter: `receiver_id=eq.${user.id}` 
              }, 
              (payload) => {
                setMessages((prevMessages) => [...prevMessages, payload.new]);
              }
            )
            .subscribe();
          return () => supabase.removeChannel(channel);
        } else {
          setMessages([]);
        }
      }, [selectedPatient, user?.id]);
      
      useEffect(() => {
        scrollToBottom();
      }, [messages]);

      const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      };

      const fetchPatientsForSelect = async () => {
        const { data, error } = await supabase
          .from('patients')
          .select('id, name, doctors!inner(profile_image_url)') // Assuming patients table has doctor_id
          .eq('doctor_id', user.id)
          .order('name');
        if (error) toast({ title: 'Error', description: 'No se pudieron cargar los pacientes.', variant: 'destructive' });
        else setPatients(data || []);
      };

      const fetchMessages = async () => {
        if (!selectedPatient) return;
        setIsLoadingMessages(true);
        const { data, error } = await supabase
          .from('messages')
          .select('*')
          .or(`(sender_id.eq.${user.id},receiver_id.eq.${selectedPatient.id}),(sender_id.eq.${selectedPatient.id},receiver_id.eq.${user.id})`)
          .order('created_at', { ascending: true });

        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los mensajes: ' + error.message, variant: 'destructive' });
        } else {
          setMessages(data || []);
        }
        setIsLoadingMessages(false);
      };

      const handleSendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !selectedPatient) return;
        setIsSending(true);

        const messageData = {
          sender_id: user.id,
          receiver_id: selectedPatient.id,
          sender_role: 'doctor',
          receiver_role: 'patient',
          content: newMessage.trim(),
        };

        const { data: insertedMessage, error } = await supabase.from('messages').insert(messageData).select().single();

        if (error) {
          toast({ title: 'Error', description: 'No se pudo enviar el mensaje: ' + error.message, variant: 'destructive' });
        } else {
          setNewMessage('');
          setMessages(prev => [...prev, insertedMessage]); // Optimistic update
        }
        setIsSending(false);
      };
      
      const filteredPatients = patients.filter(p => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      return (
        <Card className="shadow-xl w-full">
          <CardHeader>
            <CardTitle className="text-2xl font-semibold text-primary">Mensajería con Pacientes</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-200px)] md:h-[calc(100vh-250px)]">
            <div className="md:col-span-1 flex flex-col border-r pr-4">
              <Input 
                placeholder="Buscar paciente..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="mb-3"
              />
              {filteredPatients.length > 0 ? (
                <ul className="space-y-1 flex-grow overflow-y-auto">
                  {filteredPatients.map(p => (
                    <li key={p.id}>
                      <Button 
                        variant={selectedPatient?.id === p.id ? "secondary" : "ghost"} 
                        className={`w-full justify-start items-center text-left h-auto py-2 ${selectedPatient?.id === p.id ? 'font-semibold bg-primary/10' : ''}`}
                        onClick={() => setSelectedPatient(p)}
                      >
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarImage src={p.doctors?.profile_image_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(p.name)}&background=random`} alt={p.name} />
                          <AvatarFallback>{p.name.substring(0,1)}</AvatarFallback>
                        </Avatar>
                         {p.name}
                      </Button>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-slate-500 text-center py-4">No se encontraron pacientes.</p>
              )}
            </div>

            <div className="md:col-span-2 flex flex-col">
              {selectedPatient ? (
                <>
                  <div className="flex items-center mb-3 border-b pb-2">
                     <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={selectedPatient.doctors?.profile_image_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedPatient.name)}&background=random`} alt={selectedPatient.name} />
                        <AvatarFallback>{selectedPatient.name.substring(0,1)}</AvatarFallback>
                    </Avatar>
                    <h3 className="text-lg font-medium text-slate-800">
                      Chat con: <span className="text-primary">{selectedPatient.name}</span>
                    </h3>
                  </div>
                  <div className="flex-grow overflow-y-auto mb-4 p-3 space-y-4 bg-slate-50 rounded-md shadow-inner">
                    {isLoadingMessages ? <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> :
                      messages.length > 0 ? (
                        messages.map(msg => (
                          <div key={msg.id} className={`flex flex-col ${msg.sender_id === user.id ? 'items-end' : 'items-start'}`}>
                            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-xl shadow-md ${msg.sender_id === user.id ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-white text-slate-800 border rounded-bl-none'}`}>
                              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            </div>
                            <p className={`text-xs mt-1 ${msg.sender_id === user.id ? 'text-slate-400 mr-1' : 'text-slate-400 ml-1'}`}>
                                {formatDistanceToNow(parseISO(msg.created_at), { addSuffix: true, locale: es })}
                            </p>
                          </div>
                        ))
                      ) : 
                      <div className="flex flex-col items-center justify-center h-full text-slate-400">
                        <Smile size={48} className="mb-2"/>
                        <p className="text-sm">Aún no hay mensajes en este chat.</p>
                        <p className="text-xs">¡Envía el primer mensaje!</p>
                      </div>
                    }
                    <div ref={messagesEndRef} />
                  </div>
                  <form onSubmit={handleSendMessage} className="flex gap-2 items-end">
                    <Textarea 
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Escribe tu mensaje..."
                      className="flex-grow resize-none shadow-sm focus:ring-primary"
                      rows={1}
                      onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(e);}}}
                    />
                    <Button type="submit" disabled={isSending || !newMessage.trim()} className="bg-primary hover:bg-primary/90 h-auto py-2.5">
                      {isSending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                    </Button>
                  </form>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 bg-slate-50 rounded-md shadow-inner">
                  <MessageSquare className="h-16 w-16 text-slate-400 mb-4" />
                  <p className="text-lg">Selecciona un paciente para ver los mensajes.</p>
                  <p className="text-sm">Podrás comunicarte directamente con tus pacientes aquí.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      );
    };

    export default MessagesTabDoctor;
  
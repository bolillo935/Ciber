
    import React, { useState, useEffect } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle, Edit3, Trash2, Loader2, Megaphone } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const PromotionsTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [promotions, setPromotions] = useState([]);
      const [isLoading, setIsLoading] = useState(false);
      const [isPromotionDialogOpen, setIsPromotionDialogOpen] = useState(false);
      const [currentPromotion, setCurrentPromotion] = useState({ title: '', description: '', start_date: '', end_date: '', is_active: true });
      const [editingPromotion, setEditingPromotion] = useState(null);

      useEffect(() => {
        if (user && user.id) {
          fetchPromotions();
        }
      }, [user]);

      const fetchPromotions = async () => {
        if (!user || !user.id) return;
        setIsLoading(true);
        const { data, error } = await supabase
          .from('promotions')
          .select('*')
          .eq('publisher_id', user.id)
          .eq('publisher_type', 'doctor')
          .order('created_at', { ascending: false });
        if (error) toast({ title: 'Error', description: 'No se pudieron cargar las promociones: ' + error.message, variant: 'destructive' });
        else setPromotions(data || []);
        setIsLoading(false);
      };

      const handlePromotionSubmit = async (e) => {
        e.preventDefault();
        if (!currentPromotion.title) {
          toast({ title: 'Error', description: 'El título es requerido.', variant: 'destructive' });
          return;
        }

        const promotionData = {
          ...currentPromotion,
          publisher_id: user.id,
          publisher_type: 'doctor',
          target_audience: 'patients', // O podría ser 'all' o configurable
        };

        let result;
        if (editingPromotion) {
          result = await supabase.from('promotions').update(promotionData).eq('id', editingPromotion.id).select();
        } else {
          result = await supabase.from('promotions').insert(promotionData).select();
        }

        if (result.error) {
          toast({ title: 'Error', description: `No se pudo ${editingPromotion ? 'actualizar' : 'crear'} la promoción: ` + result.error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Promoción ${editingPromotion ? 'actualizada' : 'creada'} correctamente.` });
          setIsPromotionDialogOpen(false);
          fetchPromotions();
        }
      };

      const openEditPromotionDialog = (promotion) => {
        setEditingPromotion(promotion);
        setCurrentPromotion({ 
          title: promotion.title, 
          description: promotion.description || '', 
          start_date: promotion.start_date || '',
          end_date: promotion.end_date || '',
          is_active: promotion.is_active,
        });
        setIsPromotionDialogOpen(true);
      };

      const openNewPromotionDialog = () => {
        setEditingPromotion(null);
        setCurrentPromotion({ title: '', description: '', start_date: '', end_date: '', is_active: true });
        setIsPromotionDialogOpen(true);
      };

      const handleDeletePromotion = async (promotionId) => {
        if (!window.confirm("¿Estás seguro de que quieres eliminar esta promoción?")) return;
        const { error } = await supabase.from('promotions').delete().eq('id', promotionId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar la promoción: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Promoción eliminada.' });
          fetchPromotions();
        }
      };

      return (
        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl font-semibold text-primary">Promociones y Anuncios</CardTitle>
              <Button onClick={openNewPromotionDialog} className="bg-primary hover:bg-primary/90">
                <PlusCircle className="mr-2 h-5 w-5" /> Nueva Promoción
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <div className="flex justify-center items-center p-6"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
              promotions.length > 0 ? (
                <ul className="space-y-3">
                  {promotions.map(promo => (
                    <li key={promo.id} className={`p-4 border rounded-lg shadow-sm hover:shadow-md transition-shadow ${promo.is_active ? 'bg-slate-50' : 'bg-slate-200 opacity-70'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-slate-800 text-lg">{promo.title}</h3>
                          <p className="text-sm text-slate-600">{promo.description}</p>
                          <p className="text-xs text-slate-500 mt-1">
                            {promo.start_date ? `Desde: ${new Date(promo.start_date).toLocaleDateString()}` : ''}
                            {promo.end_date ? ` - Hasta: ${new Date(promo.end_date).toLocaleDateString()}` : ''}
                          </p>
                          <p className={`text-xs font-medium mt-1 ${promo.is_active ? 'text-green-600' : 'text-red-600'}`}>
                            {promo.is_active ? 'Activa' : 'Inactiva'}
                          </p>
                        </div>
                        <div className="space-x-2 flex-shrink-0">
                          <Button variant="outline" size="sm" onClick={() => openEditPromotionDialog(promo)}><Edit3 className="h-4 w-4"/></Button>
                          <Button variant="destructive" size="sm" onClick={() => handleDeletePromotion(promo.id)}><Trash2 className="h-4 w-4"/></Button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : 
                <div className="text-center py-10">
                    <Megaphone className="mx-auto h-12 w-12 text-slate-400" />
                    <p className="mt-2 text-sm text-slate-500">No hay promociones creadas.</p>
                </div>
            )}
          </CardContent>

          <Dialog open={isPromotionDialogOpen} onOpenChange={setIsPromotionDialogOpen}>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingPromotion ? 'Editar Promoción' : 'Nueva Promoción'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handlePromotionSubmit}>
                <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="space-y-1">
                    <Label htmlFor="promo_title">Título</Label>
                    <Input id="promo_title" value={currentPromotion.title} onChange={(e) => setCurrentPromotion({...currentPromotion, title: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="promo_description">Descripción (Opcional)</Label>
                    <Textarea id="promo_description" value={currentPromotion.description} onChange={(e) => setCurrentPromotion({...currentPromotion, description: e.target.value})} rows={3}/>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="promo_start_date">Fecha de Inicio (Opcional)</Label>
                      <Input id="promo_start_date" type="date" value={currentPromotion.start_date} onChange={(e) => setCurrentPromotion({...currentPromotion, start_date: e.target.value})} />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="promo_end_date">Fecha de Fin (Opcional)</Label>
                      <Input id="promo_end_date" type="date" value={currentPromotion.end_date} onChange={(e) => setCurrentPromotion({...currentPromotion, end_date: e.target.value})} />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <Checkbox id="promo_is_active" checked={currentPromotion.is_active} onCheckedChange={(checked) => setCurrentPromotion({...currentPromotion, is_active: checked})} />
                    <Label htmlFor="promo_is_active">Activa</Label>
                  </div>
                </div>
                <DialogFooter className="mt-4">
                  <Button type="button" variant="outline" onClick={() => setIsPromotionDialogOpen(false)}>Cancelar</Button>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">{editingPromotion ? 'Actualizar' : 'Crear'}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      );
    };

    export default PromotionsTab;
  

    import React, { useState, useEffect } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { supabase } from '@/lib/supabaseClient';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Loader2, UploadCloud, Image as ImageIcon, Link as LinkIcon, Save } from 'lucide-react';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

    const DoctorSettingsTab = () => {
      const { user, loading: authLoading } = useAuth();
      const { toast } = useToast();
      const [formData, setFormData] = useState({
        name: '',
        specialty: '',
        office_address: '',
        office_hours: { Lunes: '', Martes: '', Miercoles: '', Jueves: '', Viernes: '', Sabado: '', Domingo: '' },
        biography: '',
        social_media_links: { facebook: '', instagram: '', linkedin: '', website: '' },
        profile_image_url: '',
        clinic_logo_url: '',
      });
      const [isLoading, setIsLoading] = useState(false);
      const [profileImageFile, setProfileImageFile] = useState(null);
      const [clinicLogoFile, setClinicLogoFile] = useState(null);

      useEffect(() => {
        if (user && !authLoading) {
          setFormData({
            name: user.name || '',
            specialty: user.specialty || '',
            office_address: user.office_address || '',
            office_hours: user.office_hours || { Lunes: '', Martes: '', Miercoles: '', Jueves: '', Viernes: '', Sabado: '', Domingo: '' },
            biography: user.biography || '',
            social_media_links: user.social_media_links || { facebook: '', instagram: '', linkedin: '', website: '' },
            profile_image_url: user.profile_image_url || '',
            clinic_logo_url: user.clinic_logo_url || '',
          });
        }
      }, [user, authLoading]);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };

      const handleOfficeHoursChange = (day, value) => {
        setFormData(prev => ({
          ...prev,
          office_hours: { ...prev.office_hours, [day]: value }
        }));
      };
      
      const handleSocialMediaChange = (platform, value) => {
        setFormData(prev => ({
          ...prev,
          social_media_links: { ...prev.social_media_links, [platform]: value }
        }));
      };

      const handleFileChange = (e, type) => {
        const file = e.target.files[0];
        if (file) {
          if (type === 'profile') setProfileImageFile(file);
          if (type === 'logo') setClinicLogoFile(file);
        }
      };

      const uploadFile = async (file, bucket, path) => {
        if (!file) return null;
        const filePath = `${path}/${user.id}/${Date.now()}_${file.name}`;
        const { data, error } = await supabase.storage.from(bucket).upload(filePath, file);
        if (error) {
          toast({ title: 'Error de Subida', description: `No se pudo subir ${file.name}: ${error.message}`, variant: 'destructive' });
          throw error;
        }
        const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(filePath);
        return publicUrl;
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        try {
          let profileImageUrl = formData.profile_image_url;
          if (profileImageFile) {
            profileImageUrl = await uploadFile(profileImageFile, 'avatars', 'doctors_profile');
          }

          let clinicLogoUrl = formData.clinic_logo_url;
          if (clinicLogoFile) {
            clinicLogoUrl = await uploadFile(clinicLogoFile, 'logos', 'clinics_logo');
          }

          const updateData = {
            ...formData,
            profile_image_url: profileImageUrl,
            clinic_logo_url: clinicLogoUrl,
          };
          
          // Remove potentially undefined fields if they were not changed or uploaded
          Object.keys(updateData).forEach(key => updateData[key] === undefined && delete updateData[key]);


          const { error } = await supabase
            .from('doctors')
            .update(updateData)
            .eq('id', user.id);

          if (error) throw error;

          toast({ title: 'Éxito', description: 'Tu información ha sido actualizada.' });
          // Optionally, refresh user data in AuthContext here if it's not automatically updated
        } catch (error) {
          toast({ title: 'Error', description: 'No se pudo actualizar la información: ' + error.message, variant: 'destructive' });
        } finally {
          setIsLoading(false);
          setProfileImageFile(null);
          setClinicLogoFile(null);
        }
      };
      
      const daysOfWeek = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo'];

      if (authLoading) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="h-12 w-12 text-primary animate-spin" /></div>;
      }

      return (
        <Card className="shadow-xl max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl font-semibold text-primary">Configuración del Perfil</CardTitle>
            <CardDescription>Actualiza tu información personal y profesional.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-8">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div>
                  <Label htmlFor="profile_image_url" className="block text-sm font-medium text-slate-700 mb-1">Foto de Perfil</Label>
                  <Avatar className="h-24 w-24 mb-2">
                    <AvatarImage src={profileImageFile ? URL.createObjectURL(profileImageFile) : formData.profile_image_url} alt="Foto de perfil" />
                    <AvatarFallback><ImageIcon className="h-10 w-10 text-slate-400" /></AvatarFallback>
                  </Avatar>
                  <Input id="profile_image_url" type="file" onChange={(e) => handleFileChange(e, 'profile')} className="text-sm" accept="image/*" />
                </div>
                <div>
                  <Label htmlFor="clinic_logo_url" className="block text-sm font-medium text-slate-700 mb-1">Logo del Consultorio</Label>
                   <div className="w-24 h-24 mb-2 border rounded flex items-center justify-center bg-slate-50">
                    {clinicLogoFile ? <img src={URL.createObjectURL(clinicLogoFile)} alt="Logo" className="max-h-full max-w-full object-contain"/> : 
                     formData.clinic_logo_url ? <img src={formData.clinic_logo_url} alt="Logo" className="max-h-full max-w-full object-contain"/> : 
                     <ImageIcon className="h-10 w-10 text-slate-400" />}
                  </div>
                  <Input id="clinic_logo_url" type="file" onChange={(e) => handleFileChange(e, 'logo')} className="text-sm" accept="image/*" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <Label htmlFor="name">Nombre Completo</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="specialty">Especialidad</Label>
                  <Input id="specialty" name="specialty" value={formData.specialty} onChange={handleInputChange} />
                </div>
              </div>

              <div className="space-y-1">
                <Label htmlFor="office_address">Dirección del Consultorio</Label>
                <Input id="office_address" name="office_address" value={formData.office_address} onChange={handleInputChange} />
              </div>

              <div className="space-y-1">
                <Label htmlFor="biography">Biografía Profesional</Label>
                <Textarea id="biography" name="biography" value={formData.biography} onChange={handleInputChange} rows={4} placeholder="Describe tu experiencia, enfoque, etc." />
              </div>

              <div>
                <Label className="block text-sm font-medium text-slate-700 mb-2">Horarios de Atención</Label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
                  {daysOfWeek.map(day => (
                    <div key={day} className="space-y-1">
                      <Label htmlFor={`office_hours_${day}`} className="text-xs text-slate-600">{day}</Label>
                      <Input 
                        id={`office_hours_${day}`} 
                        value={formData.office_hours[day] || ''} 
                        onChange={(e) => handleOfficeHoursChange(day, e.target.value)} 
                        placeholder="Ej: 9am - 5pm / Cerrado"
                      />
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-slate-700 mb-2">Redes Sociales y Enlaces</Label>
                <div className="space-y-3">
                    {Object.entries(formData.social_media_links).map(([platform, link]) => (
                        <div key={platform} className="flex items-center gap-2">
                            <Label htmlFor={`social_${platform}`} className="capitalize w-20 text-xs text-slate-600">{platform}</Label>
                            <Input 
                                id={`social_${platform}`} 
                                value={link} 
                                onChange={(e) => handleSocialMediaChange(platform, e.target.value)} 
                                placeholder={`Enlace de ${platform}`}
                                type="url"
                            />
                        </div>
                    ))}
                </div>
              </div>


              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={isLoading} className="bg-primary hover:bg-primary/90">
                  {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  Guardar Cambios
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      );
    };

    export default DoctorSettingsTab;
  
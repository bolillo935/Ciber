
    import React, { useState, useEffect } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle, Edit3, Trash2, Loader2, ListChecks } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const PrescriptionsTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [patients, setPatients] = useState([]);
      const [selectedPatientId, setSelectedPatientId] = useState('');
      const [prescriptions, setPrescriptions] = useState([]);
      const [isLoadingPrescriptions, setIsLoadingPrescriptions] = useState(false);
      const [isPrescriptionDialogOpen, setIsPrescriptionDialogOpen] = useState(false);
      const [currentPrescription, setCurrentPrescription] = useState({ medication: '', dosage: '', instructions: '', duration: '', notes: '', issue_date: new Date().toISOString().split('T')[0]});
      const [editingPrescription, setEditingPrescription] = useState(null);

      useEffect(() => {
        if (user && user.id) {
          fetchPatientsForSelect();
        }
      }, [user]);

      useEffect(() => {
        if (selectedPatientId) {
          fetchPrescriptions();
        } else {
          setPrescriptions([]);
        }
      }, [selectedPatientId]);

      const fetchPatientsForSelect = async () => {
        const { data, error } = await supabase.from('patients').select('id, name').eq('doctor_id', user.id).order('name');
        if (error) toast({ title: 'Error', description: 'No se pudieron cargar los pacientes.', variant: 'destructive' });
        else setPatients(data || []);
      };

      const fetchPrescriptions = async () => {
        if (!selectedPatientId) return;
        setIsLoadingPrescriptions(true);
        const { data, error } = await supabase
          .from('prescriptions')
          .select('*')
          .eq('patient_id', selectedPatientId)
          .eq('doctor_id', user.id)
          .order('issue_date', { ascending: false });
        if (error) toast({ title: 'Error', description: 'No se pudieron cargar las recetas: ' + error.message, variant: 'destructive' });
        else setPrescriptions(data || []);
        setIsLoadingPrescriptions(false);
      };

      const handlePrescriptionSubmit = async (e) => {
        e.preventDefault();
        if (!currentPrescription.medication || !currentPrescription.issue_date) {
          toast({ title: 'Error', description: 'Medicamento y fecha son requeridos.', variant: 'destructive' });
          return;
        }

        const prescriptionData = {
          ...currentPrescription,
          patient_id: selectedPatientId,
          doctor_id: user.id,
        };

        let result;
        if (editingPrescription) {
          result = await supabase.from('prescriptions').update(prescriptionData).eq('id', editingPrescription.id).select();
        } else {
          result = await supabase.from('prescriptions').insert(prescriptionData).select();
        }

        if (result.error) {
          toast({ title: 'Error', description: `No se pudo ${editingPrescription ? 'actualizar' : 'crear'} la receta: ` + result.error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Receta ${editingPrescription ? 'actualizada' : 'creada'} correctamente.` });
          setIsPrescriptionDialogOpen(false);
          fetchPrescriptions();
        }
      };

      const openEditPrescriptionDialog = (prescription) => {
        setEditingPrescription(prescription);
        setCurrentPrescription({ 
          medication: prescription.medication, 
          dosage: prescription.dosage || '', 
          instructions: prescription.instructions || '',
          duration: prescription.duration || '',
          notes: prescription.notes || '',
          issue_date: prescription.issue_date,
        });
        setIsPrescriptionDialogOpen(true);
      };

      const openNewPrescriptionDialog = () => {
        setEditingPrescription(null);
        setCurrentPrescription({ medication: '', dosage: '', instructions: '', duration: '', notes: '', issue_date: new Date().toISOString().split('T')[0] });
        setIsPrescriptionDialogOpen(true);
      };

      const handleDeletePrescription = async (prescriptionId) => {
        if (!window.confirm("¿Estás seguro de que quieres eliminar esta receta?")) return;
        const { error } = await supabase.from('prescriptions').delete().eq('id', prescriptionId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar la receta: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Receta eliminada.' });
          fetchPrescriptions();
        }
      };
      
      return (
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-semibold text-primary">Gestión de Recetas Médicas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <Label htmlFor="patient-select-prescription" className="mb-2 block text-sm font-medium text-gray-700">Seleccionar Paciente</Label>
              <select
                id="patient-select-prescription"
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm bg-white"
              >
                <option value="">-- Elige un paciente --</option>
                {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>

            {selectedPatientId && (
              <div>
                <div className="flex justify-end mb-4">
                  <Button onClick={openNewPrescriptionDialog} className="bg-primary hover:bg-primary/90">
                    <PlusCircle className="mr-2 h-5 w-5" /> Nueva Receta
                  </Button>
                </div>
                {isLoadingPrescriptions ? <div className="flex justify-center items-center p-6"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
                  prescriptions.length > 0 ? (
                    <ul className="space-y-4">
                      {prescriptions.map(presc => (
                        <li key={presc.id} className="p-4 border bg-slate-50 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-slate-800 text-lg">{presc.medication}</h3>
                              <p className="text-sm text-slate-600">Fecha: {new Date(presc.issue_date).toLocaleDateString()}</p>
                              {presc.dosage && <p className="text-sm text-slate-600">Dosis: {presc.dosage}</p>}
                            </div>
                            <div className="space-x-2 flex-shrink-0">
                              <Button variant="outline" size="sm" onClick={() => openEditPrescriptionDialog(presc)}><Edit3 className="h-4 w-4"/></Button>
                              <Button variant="destructive" size="sm" onClick={() => handleDeletePrescription(presc.id)}><Trash2 className="h-4 w-4"/></Button>
                            </div>
                          </div>
                          {presc.instructions && <p className="text-sm text-slate-700 mt-1">Instrucciones: {presc.instructions}</p>}
                          {presc.duration && <p className="text-sm text-slate-700 mt-1">Duración: {presc.duration}</p>}
                          {presc.notes && <p className="text-xs text-slate-500 mt-1">Notas: {presc.notes}</p>}
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-slate-500 text-center py-4">No hay recetas para este paciente.</p>
                )}
              </div>
            )}
            {!selectedPatientId && (
                <div className="text-center py-10">
                    <ListChecks className="mx-auto h-12 w-12 text-slate-400" />
                    <p className="mt-2 text-sm text-slate-500">Selecciona un paciente para ver o añadir recetas médicas.</p>
                </div>
            )}
          </CardContent>

          <Dialog open={isPrescriptionDialogOpen} onOpenChange={setIsPrescriptionDialogOpen}>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingPrescription ? 'Editar Receta' : 'Nueva Receta'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handlePrescriptionSubmit}>
                <div className="grid gap-3 py-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="space-y-1">
                    <Label htmlFor="issue_date">Fecha de Emisión</Label>
                    <Input id="issue_date" type="date" value={currentPrescription.issue_date} onChange={(e) => setCurrentPrescription({...currentPrescription, issue_date: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="medication">Medicamento</Label>
                    <Input id="medication" value={currentPrescription.medication} onChange={(e) => setCurrentPrescription({...currentPrescription, medication: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="dosage">Dosis</Label>
                    <Input id="dosage" value={currentPrescription.dosage} onChange={(e) => setCurrentPrescription({...currentPrescription, dosage: e.target.value})} />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="instructions">Instrucciones</Label>
                    <Textarea id="instructions" value={currentPrescription.instructions} onChange={(e) => setCurrentPrescription({...currentPrescription, instructions: e.target.value})} rows={3}/>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="duration">Duración</Label>
                    <Input id="duration" value={currentPrescription.duration} onChange={(e) => setCurrentPrescription({...currentPrescription, duration: e.target.value})} />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="prescription_notes">Notas Adicionales</Label>
                    <Textarea id="prescription_notes" value={currentPrescription.notes} onChange={(e) => setCurrentPrescription({...currentPrescription, notes: e.target.value})} rows={2}/>
                  </div>
                </div>
                <DialogFooter className="mt-4">
                  <Button type="button" variant="outline" onClick={() => setIsPrescriptionDialogOpen(false)}>Cancelar</Button>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">{editingPrescription ? 'Actualizar Receta' : 'Crear Receta'}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      );
    };

    export default PrescriptionsTab;
  
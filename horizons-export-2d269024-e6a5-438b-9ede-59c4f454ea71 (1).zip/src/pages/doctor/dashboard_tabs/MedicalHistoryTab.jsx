
    import React, { useState, useEffect } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle, Edit3, Trash2, Loader2, FileText } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const MedicalHistoryTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [patients, setPatients] = useState([]);
      const [selectedPatientId, setSelectedPatientId] = useState('');
      const [medicalRecords, setMedicalRecords] = useState([]);
      const [isLoadingRecords, setIsLoadingRecords] = useState(false);
      const [isRecordDialogOpen, setIsRecordDialogOpen] = useState(false);
      const [currentRecord, setCurrentRecord] = useState({ title: '', record_date: new Date().toISOString().split('T')[0], content_text: '', content_type:'text' });
      const [editingRecord, setEditingRecord] = useState(null);

      useEffect(() => {
        if (user && user.id) {
          fetchPatientsForSelect();
        }
      }, [user]);

      useEffect(() => {
        if (selectedPatientId) {
          fetchMedicalRecords();
        } else {
          setMedicalRecords([]);
        }
      }, [selectedPatientId]);

      const fetchPatientsForSelect = async () => {
        const { data, error } = await supabase.from('patients').select('id, name').eq('doctor_id', user.id).order('name');
        if (error) toast({ title: 'Error', description: 'No se pudieron cargar los pacientes.', variant: 'destructive' });
        else setPatients(data || []);
      };

      const fetchMedicalRecords = async () => {
        if (!selectedPatientId) return;
        setIsLoadingRecords(true);
        const { data, error } = await supabase
          .from('medical_records')
          .select('*')
          .eq('patient_id', selectedPatientId)
          .eq('doctor_id', user.id)
          .order('record_date', { ascending: false });
        if (error) toast({ title: 'Error', description: 'No se pudo cargar el historial: ' + error.message, variant: 'destructive' });
        else setMedicalRecords(data || []);
        setIsLoadingRecords(false);
      };

      const handleRecordSubmit = async (e) => {
        e.preventDefault();
        if (!currentRecord.title || !currentRecord.record_date || !currentRecord.content_text) {
          toast({ title: 'Error', description: 'Título, fecha y contenido son requeridos.', variant: 'destructive' });
          return;
        }

        const recordData = {
          ...currentRecord,
          patient_id: selectedPatientId,
          doctor_id: user.id,
        };

        let result;
        if (editingRecord) {
          result = await supabase.from('medical_records').update(recordData).eq('id', editingRecord.id).select();
        } else {
          result = await supabase.from('medical_records').insert(recordData).select();
        }

        if (result.error) {
          toast({ title: 'Error', description: `No se pudo ${editingRecord ? 'actualizar' : 'guardar'} la entrada: ` + result.error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Entrada ${editingRecord ? 'actualizada' : 'guardada'} correctamente.` });
          setIsRecordDialogOpen(false);
          fetchMedicalRecords();
        }
      };

      const openEditRecordDialog = (record) => {
        setEditingRecord(record);
        setCurrentRecord({ 
          title: record.title, 
          record_date: record.record_date, 
          content_text: record.content_text || '',
          content_type: record.content_type || 'text',
          notes: record.notes || '',
        });
        setIsRecordDialogOpen(true);
      };

      const openNewRecordDialog = () => {
        setEditingRecord(null);
        setCurrentRecord({ title: '', record_date: new Date().toISOString().split('T')[0], content_text: '', content_type: 'text', notes: '' });
        setIsRecordDialogOpen(true);
      };

      const handleDeleteRecord = async (recordId) => {
        if (!window.confirm("¿Estás seguro de que quieres eliminar esta entrada del historial?")) return;
        const { error } = await supabase.from('medical_records').delete().eq('id', recordId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar la entrada: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Entrada eliminada.' });
          fetchMedicalRecords();
        }
      };

      return (
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-semibold text-primary">Historial Clínico</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <Label htmlFor="patient-select-history" className="mb-2 block text-sm font-medium text-gray-700">Seleccionar Paciente</Label>
              <select
                id="patient-select-history"
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm bg-white"
              >
                <option value="">-- Elige un paciente --</option>
                {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>

            {selectedPatientId && (
              <div>
                <div className="flex justify-end mb-4">
                  <Button onClick={openNewRecordDialog} className="bg-primary hover:bg-primary/90">
                    <PlusCircle className="mr-2 h-5 w-5" /> Nueva Entrada
                  </Button>
                </div>
                {isLoadingRecords ? <div className="flex justify-center items-center p-6"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
                  medicalRecords.length > 0 ? (
                    <ul className="space-y-4">
                      {medicalRecords.map(record => (
                        <li key={record.id} className="p-4 border bg-slate-50 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-slate-800 text-lg">{record.title}</h3>
                              <p className="text-sm text-slate-600">Fecha: {new Date(record.record_date).toLocaleDateString()}</p>
                            </div>
                            <div className="space-x-2 flex-shrink-0">
                              <Button variant="outline" size="sm" onClick={() => openEditRecordDialog(record)}><Edit3 className="h-4 w-4"/></Button>
                              <Button variant="destructive" size="sm" onClick={() => handleDeleteRecord(record.id)}><Trash2 className="h-4 w-4"/></Button>
                            </div>
                          </div>
                          <p className="text-sm text-slate-700 mt-2 whitespace-pre-wrap">{record.content_text}</p>
                          {record.notes && <p className="text-xs text-slate-500 mt-1">Notas Adicionales: {record.notes}</p>}
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-slate-500 text-center py-4">No hay entradas en el historial para este paciente.</p>
                )}
              </div>
            )}
             {!selectedPatientId && (
                <div className="text-center py-10">
                    <FileText className="mx-auto h-12 w-12 text-slate-400" />
                    <p className="mt-2 text-sm text-slate-500">Selecciona un paciente para ver o añadir entradas a su historial clínico.</p>
                </div>
            )}
          </CardContent>

          <Dialog open={isRecordDialogOpen} onOpenChange={setIsRecordDialogOpen}>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingRecord ? 'Editar Entrada de Historial' : 'Nueva Entrada de Historial'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleRecordSubmit}>
                <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="space-y-1">
                    <Label htmlFor="record_title">Título</Label>
                    <Input id="record_title" value={currentRecord.title} onChange={(e) => setCurrentRecord({...currentRecord, title: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="record_date">Fecha</Label>
                    <Input id="record_date" type="date" value={currentRecord.record_date} onChange={(e) => setCurrentRecord({...currentRecord, record_date: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="record_content">Contenido</Label>
                    <Textarea id="record_content" value={currentRecord.content_text} onChange={(e) => setCurrentRecord({...currentRecord, content_text: e.target.value})} rows={5} required />
                  </div>
                   <div className="space-y-1">
                    <Label htmlFor="record_notes">Notas Adicionales (Opcional)</Label>
                    <Textarea id="record_notes" value={currentRecord.notes || ''} onChange={(e) => setCurrentRecord({...currentRecord, notes: e.target.value})} rows={2} />
                  </div>
                </div>
                <DialogFooter className="mt-4">
                  <Button type="button" variant="outline" onClick={() => setIsRecordDialogOpen(false)}>Cancelar</Button>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">{editingRecord ? 'Actualizar Entrada' : 'Guardar Entrada'}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      );
    };

    export default MedicalHistoryTab;
  
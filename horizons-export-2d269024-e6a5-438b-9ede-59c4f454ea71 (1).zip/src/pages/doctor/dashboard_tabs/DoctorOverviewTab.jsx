
    import React, { useEffect, useState } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { supabase } from '@/lib/supabaseClient';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { Users, CalendarClock, DollarSign, BarChart3, Loader2, AlertTriangle } from 'lucide-react';
    import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
    import { format, subDays, startOfMonth, endOfMonth, startOfWeek, endOfWeek } from 'date-fns';
    import { es } from 'date-fns/locale';

    const StatCard = ({ title, value, icon, description, colorClass = "text-primary" }) => (
      <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
          {React.cloneElement(icon, { className: `h-5 w-5 ${colorClass}` })}
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-slate-800">{value}</div>
          {description && <p className="text-xs text-muted-foreground pt-1">{description}</p>}
        </CardContent>
      </Card>
    );

    const DoctorOverviewTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [stats, setStats] = useState({ totalPatients: 0, upcomingAppointments: 0, monthlyIncome: 0 });
      const [appointmentsData, setAppointmentsData] = useState([]);
      const [incomeData, setIncomeData] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const [error, setError] = useState(null);

      useEffect(() => {
        if (user && user.id) {
          fetchDashboardData();
        }
      }, [user]);

      const fetchDashboardData = async () => {
        setIsLoading(true);
        setError(null);
        try {
          const today = new Date();
          const nextWeek = new Date();
          nextWeek.setDate(today.getDate() + 7);

          const { count: totalPatients, error: patientsError } = await supabase
            .from('patients')
            .select('*', { count: 'exact', head: true })
            .eq('doctor_id', user.id);
          if (patientsError) throw patientsError;

          const { count: upcomingAppointments, error: appointmentsError } = await supabase
            .from('appointments')
            .select('*', { count: 'exact', head: true })
            .eq('doctor_id', user.id)
            .gte('start_time', today.toISOString())
            .lte('start_time', nextWeek.toISOString());
          if (appointmentsError) throw appointmentsError;
          
          const firstDayOfMonth = startOfMonth(today);
          const lastDayOfMonth = endOfMonth(today);

          const { data: monthlyTransactions, error: financesError } = await supabase
            .from('finances')
            .select('amount, type, transaction_date')
            .eq('doctor_id', user.id)
            .gte('transaction_date', format(firstDayOfMonth, 'yyyy-MM-dd'))
            .lte('transaction_date', format(lastDayOfMonth, 'yyyy-MM-dd'));
          if (financesError) throw financesError;

          const monthlyIncome = monthlyTransactions
            .filter(t => t.type === 'income')
            .reduce((sum, t) => sum + t.amount, 0);

          setStats({ totalPatients, upcomingAppointments, monthlyIncome });

          // Data for charts
          const { data: appointmentsForChart, error: appChartError } = await supabase
            .from('appointments')
            .select('start_time, status')
            .eq('doctor_id', user.id)
            .gte('start_time', format(subDays(today, 30), 'yyyy-MM-dd')) // Last 30 days
            .lte('start_time', today.toISOString());
          if (appChartError) throw appChartError;
          
          const appointmentsByDay = appointmentsForChart.reduce((acc, curr) => {
            const day = format(new Date(curr.start_time), 'dd MMM', { locale: es });
            acc[day] = (acc[day] || 0) + 1;
            return acc;
          }, {});
          setAppointmentsData(Object.entries(appointmentsByDay).map(([name, Citas]) => ({ name, Citas })).slice(-7)); // Last 7 days with appointments

          const incomeByDay = monthlyTransactions.filter(t => t.type === 'income').reduce((acc, curr) => {
            const day = format(new Date(curr.transaction_date), 'dd MMM', { locale: es });
            acc[day] = (acc[day] || 0) + curr.amount;
            return acc;
          }, {});
          setIncomeData(Object.entries(incomeByDay).map(([name, Ingresos]) => ({ name, Ingresos })).sort((a,b) => new Date(a.name) - new Date(b.name)));


        } catch (err) {
          console.error("Error fetching dashboard data:", err);
          setError("No se pudieron cargar los datos del resumen. " + err.message);
          toast({ title: "Error", description: "No se pudieron cargar los datos del resumen: " + err.message, variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };

      if (isLoading) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="h-12 w-12 text-primary animate-spin" /></div>;
      }

      if (error) {
        return (
          <Card className="shadow-lg border-destructive">
            <CardHeader>
              <CardTitle className="text-destructive flex items-center"><AlertTriangle className="mr-2"/> Error al Cargar</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{error}</p>
              <Button onClick={fetchDashboardData} className="mt-4">Reintentar</Button>
            </CardContent>
          </Card>
        );
      }
      
      const PIE_COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

      return (
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <StatCard title="Total de Pacientes" value={stats.totalPatients} icon={<Users />} description="Pacientes registrados actualmente" />
            <StatCard title="Próximas Citas (7 días)" value={stats.upcomingAppointments} icon={<CalendarClock />} description="Consultas programadas" colorClass="text-green-500" />
            <StatCard title="Ingresos Este Mes" value={`$${stats.monthlyIncome.toLocaleString()}`} icon={<DollarSign />} description={`Desde el ${format(startOfMonth(new Date()), 'dd MMM yyyy', { locale: es })}`} colorClass="text-amber-500" />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-slate-700">Citas en los Últimos Días</CardTitle>
                <CardDescription>Número de citas por día.</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={appointmentsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Citas" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-slate-700">Ingresos Diarios (Este Mes)</CardTitle>
                <CardDescription>Distribución de ingresos por día.</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                 <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={incomeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                    <Legend />
                    <Bar dataKey="Ingresos" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          {/* Placeholder for more charts or tables */}
          <Card className="shadow-lg">
            <CardHeader>
                <CardTitle className="text-lg font-semibold text-slate-700">Próximas Consultas (Tabla)</CardTitle>
                <CardDescription>Listado de las siguientes citas programadas.</CardDescription>
            </CardHeader>
            <CardContent>
                {/* TODO: Implement table with upcoming appointments */}
                <p className="text-sm text-slate-500">Próximamente: Tabla detallada de próximas consultas.</p>
            </CardContent>
          </Card>

        </div>
      );
    };

    export default DoctorOverviewTab;
  
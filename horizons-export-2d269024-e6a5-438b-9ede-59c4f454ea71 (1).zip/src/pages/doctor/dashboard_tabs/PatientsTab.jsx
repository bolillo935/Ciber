
    import React, { useState, useEffect, useCallback } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { UserPlus, Eye, Loader2, Trash2 } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
    import { format } from 'date-fns';
    import NewPatientDialog from '@/components/doctor/NewPatientDialog';
    import ViewPatientDialog from '@/components/doctor/ViewPatientDialog';

    const PatientsTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [patients, setPatients] = useState([]);
      const [isLoading, setIsLoading] = useState(false);
      
      const [isNewPatientDialogOpen, setIsNewPatientDialogOpen] = useState(false);
      const [isViewPatientDialogOpen, setIsViewPatientDialogOpen] = useState(false);
      const [selectedPatient, setSelectedPatient] = useState(null);

      const fetchPatients = useCallback(async () => {
        if (!user || !user.id) return;
        setIsLoading(true);
        const { data, error } = await supabase
          .from('patients')
          .select('*')
          .eq('doctor_id', user.id)
          .neq('access_code_status', 'deleted') 
          .order('name', { ascending: true });
        if (error) {
          toast({ title: 'Error', description: 'No se pudieron cargar los pacientes: ' + error.message, variant: 'destructive' });
        } else {
          setPatients(data || []);
        }
        setIsLoading(false);
      }, [user, toast]);

      useEffect(() => {
        fetchPatients();
      }, [fetchPatients]);
      
      const openViewPatientDialog = (patient) => {
        setSelectedPatient(patient);
        setIsViewPatientDialogOpen(true);
      };

      const handleDeletePatient = async (patientId, patientName) => {
        if (!window.confirm(`¿Estás seguro de que quieres eliminar al paciente ${patientName}? Esta acción no se puede deshacer y también eliminará los datos asociados (citas, historial, recetas, mensajes).`)) return;

        setIsLoading(true);
        try {
          await supabase.from('messages').delete().or(`sender_id.eq.${patientId},receiver_id.eq.${patientId}`);
          await supabase.from('prescriptions').delete().eq('patient_id', patientId);
          await supabase.from('medical_records').delete().eq('patient_id', patientId);
          await supabase.from('appointments').delete().eq('patient_id', patientId);
          
          const { error: patientDeleteError } = await supabase
            .from('patients')
            .update({ access_code_status: 'deleted', name: `Eliminado (${patientName})` })
            .eq('id', patientId);

          if (patientDeleteError) throw patientDeleteError;

          toast({ title: 'Éxito', description: `Paciente ${patientName} ha sido marcado como eliminado.` });
          fetchPatients();
          if (isViewPatientDialogOpen && selectedPatient?.id === patientId) {
            setIsViewPatientDialogOpen(false);
            setSelectedPatient(null);
          }
          
        } catch (error) {
           toast({ title: 'Error', description: 'No se pudo eliminar el paciente: ' + error.message, variant: 'destructive' });
        } finally {
          setIsLoading(false);
        }
      };

      return (
        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl font-semibold text-primary">Gestión de Pacientes</CardTitle>
              <Button onClick={() => setIsNewPatientDialogOpen(true)} className="bg-primary hover:bg-primary/90">
                <UserPlus className="mr-2 h-5 w-5" /> Nuevo Paciente
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading && patients.length === 0 ? <div className="flex justify-center items-center p-6"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
              patients.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {patients.map(p => (
                    <Card key={p.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <CardTitle className="text-lg text-primary">{p.name}</CardTitle>
                      </CardHeader>
                      <CardContent className="text-sm space-y-1">
                        <p><span className="font-semibold">Tel:</span> {p.phone_number || 'No especificado'}</p>
                        <p><span className="font-semibold">Código:</span> <span className="font-mono bg-slate-100 px-1 rounded">{p.access_code}</span> ({p.access_code_status})</p>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <Button variant="destructiveOutline" size="sm" onClick={() => handleDeletePatient(p.id, p.name)} className="text-xs">
                            <Trash2 className="h-3 w-3 mr-1"/> Eliminar
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => openViewPatientDialog(p)}><Eye className="h-4 w-4 mr-1"/> Ver Detalles</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : <p className="text-slate-500 text-center py-4">Aún no has registrado pacientes.</p>
            )}
          </CardContent>

          <NewPatientDialog
            isOpen={isNewPatientDialogOpen}
            setIsOpen={setIsNewPatientDialogOpen}
            onPatientCreated={fetchPatients}
            doctorId={user?.id}
          />

          {selectedPatient && (
            <ViewPatientDialog
              isOpen={isViewPatientDialogOpen}
              setIsOpen={setIsViewPatientDialogOpen}
              patient={selectedPatient}
              onCodeRegenerated={fetchPatients}
              onPatientDeleted={() => {
                fetchPatients();
                setIsViewPatientDialogOpen(false);
                setSelectedPatient(null);
              }}
            />
          )}
        </Card>
      );
    };
    export default PatientsTab;
  

    import React, { useState, useEffect } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { PlusCircle, Edit3, Trash2, Loader2, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

    const FinancesTab = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const [transactions, setTransactions] = useState([]);
      const [isLoading, setIsLoading] = useState(false);
      const [isTransactionDialogOpen, setIsTransactionDialogOpen] = useState(false);
      const [currentTransaction, setCurrentTransaction] = useState({ type: 'income', description: '', amount: '', category: '', transaction_date: new Date().toISOString().split('T')[0] });
      const [editingTransaction, setEditingTransaction] = useState(null);
      const [balance, setBalance] = useState(0);

      useEffect(() => {
        if (user && user.id) {
          fetchTransactions();
        }
      }, [user]);

      useEffect(() => {
        calculateBalance();
      }, [transactions]);

      const calculateBalance = () => {
        const newBalance = transactions.reduce((acc, curr) => {
          return curr.type === 'income' ? acc + parseFloat(curr.amount) : acc - parseFloat(curr.amount);
        }, 0);
        setBalance(newBalance);
      };

      const fetchTransactions = async () => {
        if (!user || !user.id) return;
        setIsLoading(true);
        const { data, error } = await supabase
          .from('finances')
          .select('*')
          .eq('doctor_id', user.id)
          .order('transaction_date', { ascending: false });
        if (error) toast({ title: 'Error', description: 'No se pudieron cargar las transacciones: ' + error.message, variant: 'destructive' });
        else setTransactions(data || []);
        setIsLoading(false);
      };

      const handleTransactionSubmit = async (e) => {
        e.preventDefault();
        if (!currentTransaction.description || !currentTransaction.amount || !currentTransaction.transaction_date) {
          toast({ title: 'Error', description: 'Descripción, monto y fecha son requeridos.', variant: 'destructive' });
          return;
        }
        if (isNaN(parseFloat(currentTransaction.amount)) || parseFloat(currentTransaction.amount) <= 0) {
            toast({ title: 'Error', description: 'El monto debe ser un número positivo.', variant: 'destructive' });
            return;
        }

        const transactionData = {
          ...currentTransaction,
          amount: parseFloat(currentTransaction.amount),
          doctor_id: user.id,
        };

        let result;
        if (editingTransaction) {
          result = await supabase.from('finances').update(transactionData).eq('id', editingTransaction.id).select();
        } else {
          result = await supabase.from('finances').insert(transactionData).select();
        }

        if (result.error) {
          toast({ title: 'Error', description: `No se pudo ${editingTransaction ? 'actualizar' : 'registrar'} la transacción: ` + result.error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: `Transacción ${editingTransaction ? 'actualizada' : 'registrada'} correctamente.` });
          setIsTransactionDialogOpen(false);
          fetchTransactions();
        }
      };

      const openEditTransactionDialog = (transaction) => {
        setEditingTransaction(transaction);
        setCurrentTransaction({ 
          type: transaction.type, 
          description: transaction.description, 
          amount: transaction.amount.toString(),
          category: transaction.category || '',
          transaction_date: transaction.transaction_date,
        });
        setIsTransactionDialogOpen(true);
      };

      const openNewTransactionDialog = () => {
        setEditingTransaction(null);
        setCurrentTransaction({ type: 'income', description: '', amount: '', category: '', transaction_date: new Date().toISOString().split('T')[0] });
        setIsTransactionDialogOpen(true);
      };

      const handleDeleteTransaction = async (transactionId) => {
        if (!window.confirm("¿Estás seguro de que quieres eliminar esta transacción?")) return;
        const { error } = await supabase.from('finances').delete().eq('id', transactionId);
        if (error) {
          toast({ title: 'Error', description: 'No se pudo eliminar la transacción: ' + error.message, variant: 'destructive' });
        } else {
          toast({ title: 'Éxito', description: 'Transacción eliminada.' });
          fetchTransactions();
        }
      };

      return (
        <Card className="shadow-xl">
          <CardHeader>
             <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                <CardTitle className="text-2xl font-semibold text-primary mb-2 sm:mb-0">Gestión Financiera</CardTitle>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                    <p className={`text-lg font-semibold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        Saldo Actual: {balance.toLocaleString('es-ES', { style: 'currency', currency: 'USD' })}
                    </p>
                    <Button onClick={openNewTransactionDialog} className="bg-primary hover:bg-primary/90 w-full sm:w-auto">
                        <PlusCircle className="mr-2 h-5 w-5" /> Nueva Transacción
                    </Button>
                </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <div className="flex justify-center items-center p-6"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
              transactions.length > 0 ? (
                <ul className="space-y-3">
                  {transactions.map(trans => (
                    <li key={trans.id} className="p-4 border bg-slate-50 rounded-lg flex justify-between items-center shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center">
                         {trans.type === 'income' ? <TrendingUp className="h-6 w-6 text-green-500 mr-3"/> : <TrendingDown className="h-6 w-6 text-red-500 mr-3"/>}
                        <div>
                          <p className={`font-semibold text-slate-800 ${trans.type === 'income' ? 'text-green-700' : 'text-red-700'}`}>{trans.description}</p>
                          <p className="text-sm text-slate-600">
                            {new Date(trans.transaction_date).toLocaleDateString()} - {trans.amount.toLocaleString('es-ES', { style: 'currency', currency: 'USD' })}
                          </p>
                          {trans.category && <p className="text-xs text-slate-500">Categoría: {trans.category}</p>}
                        </div>
                      </div>
                      <div className="space-x-2">
                        <Button variant="outline" size="sm" onClick={() => openEditTransactionDialog(trans)}><Edit3 className="h-4 w-4"/></Button>
                        <Button variant="destructive" size="sm" onClick={() => handleDeleteTransaction(trans.id)}><Trash2 className="h-4 w-4"/></Button>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : 
                <div className="text-center py-10">
                    <DollarSign className="mx-auto h-12 w-12 text-slate-400" />
                    <p className="mt-2 text-sm text-slate-500">No hay transacciones registradas.</p>
                </div>
            )}
          </CardContent>

          <Dialog open={isTransactionDialogOpen} onOpenChange={setIsTransactionDialogOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>{editingTransaction ? 'Editar Transacción' : 'Nueva Transacción'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleTransactionSubmit}>
                <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="space-y-1">
                    <Label htmlFor="transaction_date">Fecha</Label>
                    <Input id="transaction_date" type="date" value={currentTransaction.transaction_date} onChange={(e) => setCurrentTransaction({...currentTransaction, transaction_date: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="type">Tipo</Label>
                    <select id="type" value={currentTransaction.type} onChange={(e) => setCurrentTransaction({...currentTransaction, type: e.target.value})} className="block w-full p-2 border rounded-md bg-white" required>
                      <option value="income">Ingreso</option>
                      <option value="expense">Egreso</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="description">Descripción</Label>
                    <Input id="description" value={currentTransaction.description} onChange={(e) => setCurrentTransaction({...currentTransaction, description: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="amount">Monto</Label>
                    <Input id="amount" type="number" step="0.01" value={currentTransaction.amount} onChange={(e) => setCurrentTransaction({...currentTransaction, amount: e.target.value})} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="category">Categoría (Opcional)</Label>
                    <Input id="category" value={currentTransaction.category} onChange={(e) => setCurrentTransaction({...currentTransaction, category: e.target.value})} />
                  </div>
                </div>
                <DialogFooter className="mt-4">
                  <Button type="button" variant="outline" onClick={() => setIsTransactionDialogOpen(false)}>Cancelar</Button>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">{editingTransaction ? 'Actualizar' : 'Registrar'}</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      );
    };

    export default FinancesTab;
  

    import React, { useState, Suspense, lazy } from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { LogOut, LayoutDashboard, CalendarDays, UserPlus, FileText, Edit3, DollarSign, Megaphone, MessageSquare, Settings as SettingsIcon, Loader2 } from 'lucide-react';
    import { motion } from 'framer-motion';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

    const DoctorOverviewTab = lazy(() => import('@/pages/doctor/dashboard_tabs/DoctorOverviewTab'));
    const AppointmentsCalendarTab = lazy(() => import('@/pages/doctor/dashboard_tabs/AppointmentsCalendarTab'));
    const PatientsTab = lazy(() => import('@/pages/doctor/dashboard_tabs/PatientsTab'));
    const MedicalHistoryTab = lazy(() => import('@/pages/doctor/dashboard_tabs/MedicalHistoryTab'));
    const PrescriptionsTab = lazy(() => import('@/pages/doctor/dashboard_tabs/PrescriptionsTab'));
    const FinancesTab = lazy(() => import('@/pages/doctor/dashboard_tabs/FinancesTab'));
    const PromotionsTab = lazy(() => import('@/pages/doctor/dashboard_tabs/PromotionsTab'));
    const MessagesTabDoctor = lazy(() => import('@/pages/doctor/dashboard_tabs/MessagesTabDoctor'));
    const DoctorSettingsTab = lazy(() => import('@/pages/doctor/dashboard_tabs/DoctorSettingsTab'));

    const tabItems = [
      { value: "overview", label: "Resumen", icon: LayoutDashboard, component: DoctorOverviewTab },
      { value: "agenda", label: "Agenda", icon: CalendarDays, component: AppointmentsCalendarTab },
      { value: "pacientes", label: "Pacientes", icon: UserPlus, component: PatientsTab },
      { value: "historial", label: "Historial", icon: FileText, component: MedicalHistoryTab },
      { value: "recetas", label: "Recetas", icon: Edit3, component: PrescriptionsTab },
      { value: "finanzas", label: "Finanzas", icon: DollarSign, component: FinancesTab },
      { value: "promociones", label: "Promociones", icon: Megaphone, component: PromotionsTab },
      { value: "mensajes", label: "Mensajes", icon: MessageSquare, component: MessagesTabDoctor },
      { value: "configuracion", label: "Configuración", icon: SettingsIcon, component: DoctorSettingsTab },
    ];

    const DoctorDashboardPage = () => {
      const { user, logout } = useAuth();
      const [activeTab, setActiveTab] = useState("overview");

      const tabContentVariants = {
        hidden: { opacity: 0, y: 10 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.3, ease: "easeInOut" } },
      };
      
      const getInitials = (name) => {
        if (!name) return '';
        const names = name.split(' ');
        if (names.length === 1) return names[0].substring(0, 2).toUpperCase();
        return (names[0][0] + names[names.length - 1][0]).toUpperCase();
      };

      return (
        <div className="min-h-screen bg-gradient-to-br from-slate-100 to-sky-50 flex flex-col">
          <motion.header 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white shadow-md sticky top-0 z-40"
          >
            <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3 border-2 border-primary">
                  <AvatarImage src={user?.profile_image_url || ''} alt={user?.name} />
                  <AvatarFallback className="bg-primary/20 text-primary font-semibold">
                    {getInitials(user?.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-xl font-bold text-primary">{user?.name || 'Doctor'}</h1>
                  <p className="text-sm text-slate-600">{user?.specialty || 'Especialidad no definida'}</p>
                </div>
              </div>
              <Button onClick={logout} variant="outline" className="border-primary text-primary hover:bg-primary/10">
                <LogOut className="mr-2 h-4 w-4" /> Cerrar Sesión
              </Button>
            </div>
          </motion.header>

          <div className="flex-grow max-w-screen-2xl mx-auto w-full p-4 md:p-6">
            <Tabs defaultValue="overview" className="w-full" onValueChange={setActiveTab} value={activeTab}>
              <TabsList className="grid w-full grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-9 mb-6 bg-primary/5 p-1 rounded-lg">
                {tabItems.map(tab => (
                  <TabsTrigger key={tab.value} value={tab.value} className="data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-md hover:bg-primary/10 transition-all">
                    <tab.icon className="mr-1 sm:mr-2 h-4 w-4 inline-block"/>{tab.label}
                  </TabsTrigger>
                ))}
              </TabsList>

              <Suspense fallback={
                <div className="flex justify-center items-center h-96">
                  <Loader2 className="h-12 w-12 text-primary animate-spin" />
                </div>
              }>
                {tabItems.map(tab => (
                  <TabsContent key={tab.value} value={tab.value} forceMount={activeTab === tab.value}>
                    {activeTab === tab.value && (
                       <motion.div variants={tabContentVariants} initial="hidden" animate="visible">
                        <tab.component />
                       </motion.div>
                    )}
                  </TabsContent>
                ))}
              </Suspense>
            </Tabs>
          </div>
        </div>
      );
    };

    export default DoctorDashboardPage;
  

    import React, { useState } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { KeyRound, LogIn, ArrowLeft, Outdent as Tooth } from 'lucide-react';
    import { motion } from 'framer-motion';

    const LoginPagePatient = () => {
      const [accessCode, setAccessCode] = useState('');
      const { loginPatient, USER_ROLES } = useAuth();
      const navigate = useNavigate();
      const { toast } = useToast();

      const handleSubmit = async (e) => {
        e.preventDefault();
        if (!accessCode) {
          toast({ title: "Error", description: "Por favor, ingresa tu código de acceso.", variant: "destructive" });
          return;
        }
        const result = await loginPatient(accessCode);
        if (result.success) {
          toast({ title: "Éxito", description: `Bienvenido ${result.user.name}.` });
          navigate(`/dashboard/${USER_ROLES.PATIENT}`);
        } else {
          toast({ title: "Error de acceso", description: result.message, variant: "destructive" });
        }
      };

      return (
        <div className="min-h-screen flex items-center justify-center p-4 gradient-bg">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="w-full max-w-md shadow-2xl">
              <CardHeader className="text-center">
                <Tooth className="mx-auto h-12 w-12 text-primary mb-2" />
                <CardTitle className="text-3xl font-bold text-primary">Acceso Paciente</CardTitle>
                <CardDescription>Ingresa el código de acceso proporcionado por tu doctor.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="accessCode">Código de Acceso</Label>
                    <Input
                      id="accessCode"
                      type="text"
                      placeholder="Ej: CODE123"
                      value={accessCode}
                      onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
                      required
                      className="text-base"
                    />
                  </div>
                  <Button type="submit" className="w-full text-lg py-3 bg-primary hover:bg-primary/90">
                    <LogIn className="mr-2 h-5 w-5" /> Acceder
                  </Button>
                </form>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button variant="link" asChild className="text-primary">
                  <Link to="/">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Volver al inicio
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default LoginPagePatient;
  

    import React, { useState, useEffect, useCallback } from 'react';
    import { Card, CardContent } from '@/components/ui/card';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const AgendaGlobalView = ({ clinicId }) => {
        const [appointments, setAppointments] = useState([]);
        const [doctorsInClinic, setDoctorsInClinic] = useState([]);
        const [selectedDoctorId, setSelectedDoctorId] = useState('');
        const [isLoading, setIsLoading] = useState(true);
        const { toast } = useToast();

        const fetchDoctorsInClinic = useCallback(async () => {
            if(!clinicId) return;
            const { data, error } = await supabase
                .from('clinic_doctors')
                .select('doctors(id, name)')
                .eq('clinic_id', clinicId);
            if (error) {
                toast({ title: "Error", description: "No se pudieron cargar los doctores de la clínica: " + error.message, variant: "destructive" });
                setDoctorsInClinic([]);
            } else {
                setDoctorsInClinic(data.map(cd => cd.doctors).filter(doc => doc !== null) || []);
            }
        }, [clinicId, toast]);

        const fetchAppointments = useCallback(async () => {
            if (!clinicId) { setIsLoading(false); setAppointments([]); return; }
            setIsLoading(true);
            
            let query = supabase
                .from('appointments')
                .select('*, patients(name), doctors(name)')
                .order('start_time', { ascending: true });
            
            // If clinic ID is available, filter by it. This assumes appointments have clinic_id.
            // If not, this will fetch ALL appointments if selectedDoctorId is also not set.
            // This part of logic might need adjustment based on how appointments are linked to clinics.
            // The current RLS allows clinics to see appointments if clinic_id matches or if they are admin.
            // For a non-admin clinic user, they should only see their clinic's appointments.
            // If appointments are linked via doctor_id -> clinic_doctors -> clinic_id, query is more complex.
            // Simplification: Assuming appointments have `clinic_id` field.
            // And RLS policy on 'appointments' for clinics ensures they only see their own.

            // To strictly fetch for the clinic via doctors:
            if (doctorsInClinic.length > 0 && !selectedDoctorId) {
                const clinicDoctorIds = doctorsInClinic.map(d => d.id);
                query = query.in('doctor_id', clinicDoctorIds);
            } else if (selectedDoctorId) {
                 query = query.eq('doctor_id', selectedDoctorId);
            } else {
                // No doctors in clinic or no specific doctor selected, might return empty or too many if RLS is not strict
                // If a clinic_id is on appointments, use it:
                 query = query.eq('clinic_id', clinicId);
            }


            const { data, error } = await query;
            if (error) {
                toast({ title: "Error", description: "No se pudieron cargar las citas: " + error.message, variant: "destructive" });
                setAppointments([]);
            } else {
                setAppointments(data || []);
            }
            setIsLoading(false);
        }, [clinicId, selectedDoctorId, toast, doctorsInClinic]);

        useEffect(() => {
            fetchDoctorsInClinic();
        }, [fetchDoctorsInClinic]);
        
        useEffect(() => {
            // Fetch appointments only after doctorsInClinic is populated if not filtering by a specific doctor
            // or if the clinicId is directly on appointments table for filtering.
            if (doctorsInClinic.length > 0 || selectedDoctorId || clinicId) {
                 fetchAppointments();
            } else if(!isLoading && doctorsInClinic.length === 0 && !selectedDoctorId) {
                // Case: clinic has no doctors and no specific doctor filter, so no appointments to show based on doctors
                setAppointments([]);
                setIsLoading(false);
            }
        }, [fetchAppointments, doctorsInClinic, selectedDoctorId, clinicId, isLoading]);


        if (isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-purple-500" /> Cargando agenda global...</div>;


        return (
            <div>
                <div className="mb-4">
                    <Label htmlFor="doctor-filter-agenda">Filtrar por Doctor:</Label>
                    <select
                        id="doctor-filter-agenda"
                        value={selectedDoctorId}
                        onChange={(e) => setSelectedDoctorId(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white"
                        disabled={!doctorsInClinic.length}
                    >
                        <option value="">{doctorsInClinic.length ? "Todos los Doctores de esta Clínica" : "No hay doctores en esta clínica"}</option>
                        {doctorsInClinic.map(doc => <option key={doc.id} value={doc.id}>{doc.name}</option>)}
                    </select>
                </div>

                {!appointments.length && !isLoading && <p className="text-slate-500">No hay citas para mostrar con los filtros actuales.</p>}
                {appointments.length > 0 && (
                    <div className="space-y-3">
                        {appointments.map(app => (
                            <Card key={app.id}>
                                <CardContent className="p-3">
                                    <p className="font-semibold">Paciente: {app.patients?.name || 'N/A'}</p>
                                    <p className="text-sm">Doctor: {app.doctors?.name || 'N/A'}</p>
                                    <p className="text-sm text-muted-foreground">
                                        {new Date(app.start_time).toLocaleString([], {dateStyle: 'long', timeStyle: 'short'})} - {new Date(app.end_time).toLocaleTimeString([], {timeStyle: 'short'})}
                                    </p>
                                    <p className="text-xs">Estado: {app.status}</p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </div>
        );
    };
    export default AgendaGlobalView;
  
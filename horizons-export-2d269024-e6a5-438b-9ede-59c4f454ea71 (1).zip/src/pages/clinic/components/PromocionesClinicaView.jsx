
    import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Edit3, Trash2, PlusCircle, ToggleLeft, ToggleRight } from 'lucide-react';
    import { PromotionFormDialog } from '@/pages/doctor/components/PromotionFormDialog';

    const Loader2 = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

    const PromocionesClinicaView = ({ clinicId }) => {
        const [promotions, setPromotions] = useState([]);
        const [isLoading, setIsLoading] = useState(true);
        const [isFormOpen, setIsFormOpen] = useState(false);
        const [editingPromotion, setEditingPromotion] = useState(null);
        const {toast} = useToast();
  
        const fetchPromotions = useCallback(async () => {
          if(!clinicId) { setIsLoading(false); setPromotions([]); return;}
          setIsLoading(true);
          const { data, error } = await supabase
              .from('promotions')
              .select('*')
              .eq('publisher_id', clinicId)
              .eq('publisher_type', 'clinic')
              .order('created_at', { ascending: false });
          
          if(error) {
              toast({title: "Error", description: "No se pudieron cargar las promociones: " + error.message, variant: "destructive"});
              setPromotions([]);
          } else {
              setPromotions(data || []);
          }
          setIsLoading(false);
        }, [clinicId, toast]);
  
        useEffect(() => {
          fetchPromotions();
        }, [fetchPromotions]);

        const handleSavePromotion = () => {
            setIsFormOpen(false);
            setEditingPromotion(null);
            fetchPromotions();
        };

        const handleEditPromotion = (promotion) => {
            setEditingPromotion(promotion);
            setIsFormOpen(true);
        };

        const handleDeletePromotion = async (promotionId) => {
            if (!window.confirm("¿Estás seguro de que quieres eliminar esta promoción?")) return;
            
            const { error } = await supabase
            .from('promotions')
            .delete()
            .eq('id', promotionId);

            if (error) {
            toast({ title: 'Error', description: 'No se pudo eliminar la promoción: ' + error.message, variant: 'destructive' });
            } else {
            toast({ title: 'Éxito', description: 'Promoción eliminada.' });
            fetchPromotions();
            }
        };

        const togglePromotionStatus = async (promotion) => {
            const newStatus = !promotion.is_active;
            const { error } = await supabase
                .from('promotions')
                .update({ is_active: newStatus })
                .eq('id', promotion.id);

            if (error) {
                toast({ title: 'Error', description: `No se pudo ${newStatus ? 'activar' : 'desactivar'} la promoción: ${error.message}`, variant: 'destructive' });
            } else {
                toast({ title: 'Éxito', description: `Promoción ${newStatus ? 'activada' : 'desactivada'}.` });
                fetchPromotions();
            }
        };
  
        if(isLoading) return <div className="text-center p-4"><Loader2 className="h-8 w-8 animate-spin mx-auto text-purple-500" /> Cargando promociones...</div>;
  
        return (
          <div>
              <PromotionFormDialog
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                publisherId={clinicId}
                publisherType="clinic"
                promotion={editingPromotion}
                onSave={handleSavePromotion}
              />
              <Button onClick={() => {setEditingPromotion(null); setIsFormOpen(true);}} className="mb-4">
                  <PlusCircle className="mr-2 h-4 w-4" /> Nueva Promoción Institucional
              </Button>
              {!promotions.length && !isLoading && <p className="text-slate-500">La clínica no ha publicado promociones.</p>}
              {promotions.length > 0 && (
                  <div className="space-y-4">
                      {promotions.map(promo => (
                          <Card key={promo.id}>
                              <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle>{promo.title}</CardTitle>
                                        <CardDescription>
                                            {promo.start_date && promo.end_date ? 
                                            `${new Date(promo.start_date).toLocaleDateString()} - ${new Date(promo.end_date).toLocaleDateString()}` 
                                            : "Anuncio general (sin fecha límite)"}
                                        </CardDescription>
                                    </div>
                                    <Button variant="ghost" size="sm" onClick={() => togglePromotionStatus(promo)} title={promo.is_active ? "Desactivar" : "Activar"}>
                                        {promo.is_active ? <ToggleRight className="h-6 w-6 text-green-500" /> : <ToggleLeft className="h-6 w-6 text-slate-400" />}
                                    </Button>
                                </div>
                              </CardHeader>
                              <CardContent>
                                  <p className="text-sm">{promo.description || "Sin descripción detallada."}</p>
                                  <div className="mt-3 flex gap-2">
                                      <Button size="sm" variant="outline" onClick={() => handleEditPromotion(promo)}><Edit3 className="h-4 w-4 mr-1" /> Editar</Button>
                                      <Button size="sm" variant="destructive" onClick={() => handleDeletePromotion(promo.id)}><Trash2 className="h-4 w-4 mr-1" /> Eliminar</Button>
                                  </div>
                              </CardContent>
                          </Card>
                      ))}
                  </div>
              )}
          </div>
        );
    };
    export default PromocionesClinicaView;
  
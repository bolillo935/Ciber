
    import React from 'react';
    import { useAuth } from '@/contexts/AuthContext';
    import { Button } from '@/components/ui/button';
    import { LogOut, Building } from 'lucide-react';
    import { motion } from 'framer-motion';

    const ClinicDashboardPage = () => {
      const { user, logout } = useAuth();

      return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-100 p-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto"
          >
            <header className="flex justify-between items-center mb-10 pb-4 border-b border-purple-500/30">
              <div>
                <h1 className="text-4xl font-bold text-purple-600">Panel de Clínica</h1>
                {user && <p className="text-xl text-slate-600">Bienvenido, Administrador de {user.name}</p>}
              </div>
              <Button onClick={logout} variant="outline" className="border-purple-500 text-purple-600 hover:bg-purple-500/10">
                <LogOut className="mr-2 h-4 w-4" /> Cerrar Sesión
              </Button>
            </header>
            
            <div className="text-center p-10 bg-white rounded-xl shadow-xl">
              <h2 className="text-2xl text-slate-700">Funcionalidades Próximamente</h2>
              <p className="text-slate-500 mt-2">
                Aquí podrás gestionar doctores, ver agendas globales, estadísticas y más.
              </p>
              <img  alt="Modern dental clinic reception area" class="mt-6 mx-auto w-full max-w-md rounded-lg shadow-md" src="https://images.unsplash.com/photo-1616391182219-e080b4d1043a" />
            </div>
          </motion.div>
        </div>
      );
    };

    export default ClinicDashboardPage;
  
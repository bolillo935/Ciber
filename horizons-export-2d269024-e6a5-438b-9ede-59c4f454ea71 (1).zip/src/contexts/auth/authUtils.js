
    import { supabase } from '@/lib/supabaseClient';
    import { USER_ROLES } from '@/lib/constants';

    export const setSupabaseClientHeaders = (accessCode) => {
      const currentHeaders = supabase.headers;
      if (accessCode) {
        supabase.headers = {
          ...currentHeaders,
          'X-Patient-Access-Code': accessCode,
        };
      } else {
        const { 'x-patient-access-code': _, ...rest } = currentHeaders;
        supabase.headers = rest;
      }
    };

    export const fetchUserProfile = async (authUserId, userRole) => {
      try {
        let profile = null;
        let error = null;
        let email = null;

        const {data: authUserResult, error: authUserError} = await supabase.auth.getUser();
        if (authUserError) {
          console.error('Error fetching auth user for email:', authUserError.message);
        } else {
          email = authUserResult.user?.email;
        }

        if (userRole === USER_ROLES.DOCTOR) {
          const { data: doctorProfile, error: doctorError } = await supabase
            .from('doctors')
            .select('*')
            .eq('id', authUserId)
            .single();
          profile = doctorProfile;
          error = doctorError;
        } else if (userRole === USER_ROLES.CLINIC) {
          const { data: clinicProfile, error: clinicError } = await supabase
            .from('clinics')
            .select('*')
            .eq('id', authUserId)
            .single();
          profile = clinicProfile;
          error = clinicError;
        }

        if (error && error.code !== 'PGRST116') { 
          console.error(`Error fetching ${userRole} profile:`, error.message);
          return null;
        }
        return profile ? { ...profile, email, role: userRole } : null;

      } catch (e) {
        console.error(`Exception in fetchUserProfile for ${userRole}:`, e);
        return null;
      }
    };


    export const determineUserRoleAndFetchProfile = async (authUserId) => {
      let profileData = await fetchUserProfile(authUserId, USER_ROLES.DOCTOR);
      if (profileData) {
        return profileData;
      }
      profileData = await fetchUserProfile(authUserId, USER_ROLES.CLINIC);
      if (profileData) {
        return profileData;
      }
      return null;
    };


    export const getPatientDataFromLocalStorage = () => {
      const storedPatient = localStorage.getItem('currentUser');
      if (storedPatient) {
        try {
          const parsedPatient = JSON.parse(storedPatient);
          if (parsedPatient.role === USER_ROLES.PATIENT && parsedPatient.accessCode) {
            return parsedPatient;
          }
        } catch (e) {
          console.error("Error parsing stored patient data:", e);
        }
      }
      localStorage.removeItem('currentUser');
      return null;
    };
  
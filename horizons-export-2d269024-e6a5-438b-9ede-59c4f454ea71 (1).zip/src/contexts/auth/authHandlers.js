
    import { supabase } from '@/lib/supabaseClient';
    import { USER_ROLES } from '@/lib/constants';
    import { setSupabaseClientHeaders, fetchUserProfile } from './authUtils';

    export const handleLoginDoctor = async (email, password, setUser, setLoading, initializeUserSessionCallback) => {
      setLoading(true);
      try {
        const { data: sessionData, error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) {
          setLoading(false);
          return { success: false, message: signInError.message };
        }
        if (sessionData?.user) {
          await initializeUserSessionCallback(sessionData.user);
          return { success: true, user: sessionData.user }; 
        }
        setLoading(false);
        return { success: false, message: 'Error desconocido al iniciar sesión.' };
      } catch (e) {
        console.error("Exception in loginDoctor:", e);
        setLoading(false);
        return { success: false, message: 'Ocurrió un error inesperado.' };
      }
    };

    export const handleLoginClinic = async (email, password, setUser, setLoading, initializeUserSessionCallback) => {
      setLoading(true);
      try {
        const { data: sessionData, error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) {
          setLoading(false);
          return { success: false, message: signInError.message };
        }
        if (sessionData?.user) {
          await initializeUserSessionCallback(sessionData.user);
          return { success: true, user: sessionData.user };
        }
        setLoading(false);
        return { success: false, message: 'Error desconocido al iniciar sesión.' };
      } catch (e) {
        console.error("Exception in loginClinic:", e);
        setLoading(false);
        return { success: false, message: 'Ocurrió un error inesperado.' };
      }
    };
      
    export const handleLoginPatient = async (accessCode, setUser, setLoading, initializeUserSessionCallback) => {
      setLoading(true);
      try {
        const upperAccessCode = accessCode.toUpperCase();
        
        const { data: patientData, error } = await supabase
          .from('patients')
          .select(`
            *,
            doctors (
              id,
              name,
              specialty,
              profile_image_url
            )
          `)
          .eq('access_code', upperAccessCode)
          .eq('access_code_status', 'active') 
          .single();

        if (error || !patientData) {
          setSupabaseClientHeaders(null); 
          console.error("Patient login error or no data:", error ? error.message : 'No patient data or inactive code');
          setLoading(false);
          return { success: false, message: 'Código de acceso inválido o el paciente no está activo.' };
        }
        
        setSupabaseClientHeaders(upperAccessCode);

        const doctorInfo = patientData.doctors ? { 
          name: patientData.doctors.name, 
          specialty: patientData.doctors.specialty, 
          id: patientData.doctors.id,
          profile_image_url: patientData.doctors.profile_image_url
        } : null;

        const userData = { 
          id: patientData.id, 
          name: patientData.name, 
          accessCode: patientData.access_code, 
          role: USER_ROLES.PATIENT,
          assignedDoctor: doctorInfo,
          doctor_id: patientData.doctor_id,
          date_of_birth: patientData.date_of_birth,
          phone_number: patientData.phone_number,
          address: patientData.address,
        };
        localStorage.setItem('currentUser', JSON.stringify(userData));
        setUser(userData); // Directly set user, initializeUserSession will be called by AuthProvider if needed
        setLoading(false);
        return { success: true, user: userData };
      } catch (e) {
        console.error("Exception in loginPatient:", e);
        setSupabaseClientHeaders(null);
        setLoading(false);
        return { success: false, message: 'Ocurrió un error inesperado.' };
      }
    };

    export const handleLogout = async (setUser, setLoading, initializeUserSessionCallback) => {
      setLoading(true);
      try {
        const { error } = await supabase.auth.signOut();
        localStorage.removeItem('currentUser'); 
        setSupabaseClientHeaders(null); 
        setUser(null); // Set user to null immediately
        if (error) {
          console.error('Error al cerrar sesión:', error);
        }
        // No need to call initializeUserSessionCallback here, onAuthStateChange will handle it.
      } catch (e) {
        console.error("Exception in logout:", e);
      } finally {
        setLoading(false);
      }
    };
  
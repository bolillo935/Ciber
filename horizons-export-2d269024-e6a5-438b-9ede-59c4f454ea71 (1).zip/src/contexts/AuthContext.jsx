
    import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
    import { supabase } from '@/lib/supabaseClient';
    import { USER_ROLES } from '@/lib/constants';
    import { 
      setSupabaseClientHeaders, 
      determineUserRoleAndFetchProfile,
      getPatientDataFromLocalStorage 
    } from './auth/authUtils';
    import { 
      handleLoginDoctor, 
      handleLoginClinic, 
      handleLoginPatient, 
      handleLogout 
    } from './auth/authHandlers';

    const AuthContext = createContext(null);

    export const AuthProvider = ({ children }) => {
      const [user, setUser] = useState(null);
      const [loading, setLoading] = useState(true);
      
      const initializeUserSession = useCallback(async (authUser) => {
        setLoading(true);
        try {
          if (authUser) {
            setSupabaseClientHeaders(null); 
            const profileData = await determineUserRoleAndFetchProfile(authUser.id);
            if (profileData) {
              setUser(profileData);
            } else {
              console.warn(`No doctor or clinic profile found for authenticated user ID: ${authUser.id}. Signing out.`);
              await supabase.auth.signOut().catch(console.error); 
              setUser(null); 
            }
          } else {
            const patientUser = getPatientDataFromLocalStorage();
            if (patientUser) {
              const { data: validPatient, error: patientCheckError } = await supabase
                .from('patients')
                .select('id, access_code_status')
                .eq('id', patientUser.id)
                .eq('access_code', patientUser.accessCode) 
                .single();

              if (patientCheckError || !validPatient || validPatient.access_code_status !== 'active') {
                console.warn('Invalid or inactive patient session from localStorage.', patientCheckError ? patientCheckError.message : 'Patient not active or not found.');
                localStorage.removeItem('currentUser');
                setSupabaseClientHeaders(null);
                setUser(null);
              } else {
                setSupabaseClientHeaders(patientUser.accessCode);
                setUser(patientUser);
              }
            } else {
              setSupabaseClientHeaders(null);
              setUser(null);
            }
          }
        } catch (e) {
          console.error("Exception during user session initialization:", e);
          setUser(null);
        } finally {
          setLoading(false);
        }
      }, []);

      useEffect(() => {
        const manageInitialSession = async () => {
          const { data: { session }, error: sessionError } = await supabase.auth.getSession();
          if (sessionError) {
            console.error("Error getting session:", sessionError.message);
          }
          await initializeUserSession(session?.user || null);
        };
        
        manageInitialSession();

        const { data: authListener } = supabase.auth.onAuthStateChange(
          async (_event, session) => {
            await initializeUserSession(session?.user || null);
          }
        );

        return () => {
          authListener?.subscription.unsubscribe();
        };
      }, [initializeUserSession]);

      const loginDoctor = (email, password) => handleLoginDoctor(email, password, setUser, setLoading, initializeUserSession);
      const loginClinic = (email, password) => handleLoginClinic(email, password, setUser, setLoading, initializeUserSession);
      const loginPatient = (accessCode) => handleLoginPatient(accessCode, setUser, setLoading, initializeUserSession);
      const logout = () => handleLogout(setUser, setLoading, initializeUserSession);
      
      return (
        <AuthContext.Provider value={{ user, loading, loginDoctor, loginClinic, loginPatient, logout, USER_ROLES }}>
          {children}
        </AuthContext.Provider>
      );
    };

    export const useAuth = () => {
        const context = useContext(AuthContext);
        if (context === undefined) {
            throw new Error('useAuth must be used within an AuthProvider');
        }
        return context;
    };
  
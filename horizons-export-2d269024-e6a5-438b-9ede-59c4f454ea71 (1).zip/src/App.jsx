
    import React from 'react';
    import { Routes, Route, Navigate } from 'react-router-dom';
    import { useAuth } from '@/contexts/AuthContext';
    import { USER_ROLES } from '@/lib/constants';
    import HomePage from '@/pages/HomePage';
    import LoginPageDoctor from '@/pages/LoginPageDoctor';
    import LoginPagePatient from '@/pages/LoginPagePatient';
    import LoginPageClinic from '@/pages/LoginPageClinic';
    import DoctorDashboardPage from '@/pages/doctor/DoctorDashboardPage';
    import PatientDashboardPage from '@/pages/patient/PatientDashboardPage';
    import ClinicDashboardPage from '@/pages/clinic/ClinicDashboardPage';
    import ProtectedRoute from '@/components/ProtectedRoute';
    import { Toaster } from '@/components/ui/toaster';
    import { Loader2 } from 'lucide-react';

    function App() {
      const { user, loading, USER_ROLES: authUserRoles } = useAuth(); // Destructure USER_ROLES from useAuth

      if (loading) {
        return (
          <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-sky-400 to-primary">
            <Loader2 className="h-16 w-16 text-white animate-spin" />
            <p className="mt-4 text-white text-xl font-semibold">Cargando Inteligencia Dental...</p>
          </div>
        );
      }

      return (
        <>
          <Routes>
            <Route 
              path="/" 
              element={
                !user ? <HomePage /> : <Navigate to={`/dashboard/${user.role}`} replace />
              } 
            />
            <Route 
              path="/login/doctor" 
              element={
                !user ? <LoginPageDoctor /> : <Navigate to={`/dashboard/${authUserRoles.DOCTOR}`} replace />
              } 
            />
            <Route 
              path="/login/patient" 
              element={
                !user ? <LoginPagePatient /> : <Navigate to={`/dashboard/${authUserRoles.PATIENT}`} replace />
              } 
            />
            <Route 
              path="/login/clinic" 
              element={
                !user ? <LoginPageClinic /> : <Navigate to={`/dashboard/${authUserRoles.CLINIC}`} replace />
              } 
            />

            <Route 
              path="/dashboard/doctor" 
              element={
                <ProtectedRoute allowedRoles={[authUserRoles.DOCTOR]}>
                  <DoctorDashboardPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/dashboard/patient" 
              element={
                <ProtectedRoute allowedRoles={[authUserRoles.PATIENT]}>
                  <PatientDashboardPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/dashboard/clinic" 
              element={
                <ProtectedRoute allowedRoles={[authUserRoles.CLINIC]}>
                  <ClinicDashboardPage />
                </ProtectedRoute>
              } 
            />
            
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <Toaster />
        </>
      );
    }

    export default App;
  